"""Retcon simulator: the game engine, bots, tools and the web game (see RULES.md)."""

VERSION = "1.3.2"                  # the rules version: bump it with every ruling (DESIGN-LOG.md)

from .config import Config
from .cards import Kind
from .engine import new_game, legal_actions, apply, to_play, observe, clone, check_invariants

__all__ = [
    "Config", "Kind", "new_game", "legal_actions", "apply", "to_play",
    "observe", "clone", "check_invariants",
]
