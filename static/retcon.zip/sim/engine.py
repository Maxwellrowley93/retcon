"""Game engine: rounds, the trick at the Present, the Past, the sweep and card effects.

The engine is a state machine. `to_play(s)` says who must act; `legal_actions(s)`
lists their options; `apply(s, action)` mutates the state and runs every
automatic step (the sweep, scoring, locking, the next round) until someone must
decide again. Choices that arise mid-sweep (activating an Ancestor, a Wormhole's
move, a Usurper's or Courier's choice), and where a timeline splits and the new
timeline's suit after a send or recall ruptures it, are ordinary decisions for the owning
player.

Actions (tuples):
    ("trick", card)                              # the Present: play into the current timeline's trick
    ("send", card, row_id, gap, timeline)        # the Past: send a card back into that timeline's history
    ("draw",)                                    # the Past: draw a card
    ("recall", card)                             # the Past: pay recall_cost to take that card from the discard pile
    ("pass",)
    ("split", row_id, gap)                       # a send or recall ruptured its timeline: split it at that gap
    ("suit", suit)                               # ...and the new timeline's suit
    ("activate", card_uid) | ("skip", card_uid)  # the sweep reaches your Ancestor
    ("wormhole", "down" | "up" | "across" | "stay", row_or_None, card_uid_or_None)
    ("usurp", player)                            # whose lineage the Usurper removes
    ("courier", card_or_None)                    # the card the Courier delivers (None = keep it)

A card in a hand, the deck or the discard pile is a cards.Card (kind, suit).
"""

import random
from collections import Counter

from .board import Board, BoardCard, label
from .cards import Card, Kind, NAMES, SUIT_NAMES, SUITS, build_deck, card_name, distinct, kind_of, suit_of
from .config import Config

PLAYER_NAMES = ("Red", "Blue", "Green", "Yellow")
ONE_SHOT = (Kind.ASSASSIN, Kind.REVISIONIST, Kind.PROPHET)   # used up as they act (D13, D19)


class Player:
    __slots__ = ("hand", "supply", "markers", "peak_markers", "points", "charge", "tricks")

    def __init__(self, supply):
        self.hand = []
        self.supply = supply         # lineage tokens not on the board
        self.markers = 0             # signal markers on the board (no cap: they never limit play)
        self.peak_markers = 0        # the most on the board at once, to size the physical supply
        self.points = 0              # locks
        self.charge = 0              # time charge, spent to send cards back
        self.tricks = 0              # tricks won in the last sweep (sets the order in the next Past)

    def clone(self):
        p = Player.__new__(Player)
        p.hand, p.supply, p.markers, p.peak_markers = list(self.hand), self.supply, self.markers, self.peak_markers
        p.points, p.charge, p.tricks = self.points, self.charge, self.tricks
        return p


class State:
    def __init__(self, cfg, n_players, seed):
        self.cfg = cfg
        self.n = n_players
        self.rng = random.Random(seed)
        self.deck = []
        self.discard = []
        self.board = Board()
        self.players = [Player(cfg.token_supply) for _ in range(n_players)]
        self.round = 0
        self.first = 0
        self.phase = "present"       # present | past | reveal | lock | over
        self.queue = []              # player order for this phase's actions
        self.queue_rows = []         # the timeline each queued action is for
        self.pos = 0
        self.actions_this_round = 0  # tricks this round
        self.decision = None         # pending mid-sweep decision
        self.next_uid = 0
        self.winners = []
        self.end_reason = None
        self.log = [] if cfg.log else None
        self.stats = Counter()
        self.swept = set()               # cards the sweep has reached this round
        self.round_moves = {}            # card uid -> player who wormholed it this round
        self.row_created = {0: 0}        # timeline id -> round it was created
        self.locks_this_round = Counter()
        self.deck_total = 0
        self.trick_rows = []             # timelines with a trick this round
        self.trick = {}                  # uid of a card played into a trick -> {"origin": timeline, "player": p}
        self.tricks_scored = set()       # tricks scored this round
        self.shown = set()               # trick cards turned face up to score, which haven't acted yet
        self.lock_record = {}            # timeline -> {"player": p, "tally": lineage per player when it locked}
        self.instability = 0             # charge spent on sends and recalls, table-wide, towards the next rupture
        self.observer = None             # called with each log line (the web game's step-by-step replay)
        self.focus = None                # uid of the card acting right now
        self.hit = None                  # uid of the card it just affected

    def say(self, msg):
        if self.log is not None:
            self.log.append(msg)
        if self.observer is not None:
            self.observer(msg)

    def uid(self):
        self.next_uid += 1
        return self.next_uid


def pname(p):
    return PLAYER_NAMES[p]


def cname(c):
    who = pname(c.owner) + " " if c.owner is not None else ""
    return who + NAMES[c.kind]


def public(c):
    """How the table sees a card in the log: a facedown card's identity stays hidden."""
    if c.pending:
        return (pname(c.owner) + "'s facedown card") if c.owner is not None else "a facedown card"
    return cname(c)


def from_hand(item, uid, owner):
    """A card from a hand as a facedown card on the board, keeping its suit."""
    card = BoardCard(uid, kind_of(item), owner, pending=True)
    card.suit = suit_of(item)
    return card


def as_held(card):
    """A board card as it goes back to the deck or discard pile."""
    return card.kind if card.suit is None else Card(card.kind, card.suit)


def drawn_col(s, rid, i):
    """The column a card is drawn in, and named by in the log: timelines line up
    slot for slot, so a split point sits beside the last card the timelines
    share and takes no slot of its own (Board.slot)."""
    return s.board.slot(rid, i)


def draw_board(s):
    """The board drawing for the log."""
    return s.board.render()


def timeline_suit(s, rid):
    """The suit of timeline rid's Present marker."""
    return s.board.rows[rid].cards[-1].suit


def free_suits(s, exclude=None):
    """Present markers no open timeline holds: no suit (None), then ♠ ♥ ♦ ♣.
    No two open timelines share a marker; a locked timeline's goes back."""
    taken = {timeline_suit(s, t) for t in s.board.active_rows() if t != exclude}
    return [x for x in [None, *range(len(SUITS))] if x not in taken]


def total_cap(s):
    """Timelines in all, locked ones included: one more than every player can
    hold without reaching locks_to_win, so the board can't run out first."""
    return s.n * (s.cfg.locks_to_win - 1) + 1


def can_rupture(s):
    """A rupture needs a free Present marker (fewer than timeline_cap open
    timelines) and room under total_cap."""
    return len(s.board.active_rows()) < s.cfg.timeline_cap and len(s.board.rows) < total_cap(s)


# ----------------------------------------------------------------------------
# setup and public API
# ----------------------------------------------------------------------------

def new_game(cfg=None, n_players=3, seed=0):
    cfg = cfg or Config()
    s = State(cfg, n_players, seed)
    s.deck = build_deck(cfg.deck)
    s.deck_total = len(s.deck)
    s.rng.shuffle(s.deck)
    s.board.add_row(None, 0, [BoardCard(s.uid(), Kind.PRESENT, None)])   # T0 has no suit: no trump
    for p in s.players:
        p.charge = cfg.starting_charge
    s.first = s.rng.randrange(n_players)
    s.round = 1
    _start_present(s)
    return s


def clone(s, light=False):
    """Fast copy. light=True drops the log and statistics (for bot lookahead)."""
    o = State.__new__(State)
    o.__dict__.update(s.__dict__)
    o.rng = random.Random()
    o.rng.setstate(s.rng.getstate())
    o.deck = list(s.deck)
    o.discard = list(s.discard)
    o.board = s.board.clone()
    o.players = [p.clone() for p in s.players]
    o.queue = list(s.queue)
    o.queue_rows = list(s.queue_rows)
    o.decision = None if s.decision is None else dict(s.decision)
    o.winners = list(s.winners)
    o.swept = set(s.swept)
    o.round_moves = dict(s.round_moves)
    o.row_created = dict(s.row_created)
    o.locks_this_round = Counter(s.locks_this_round)
    o.trick_rows = list(s.trick_rows)
    o.trick = {u: dict(m) for u, m in s.trick.items()}
    o.tricks_scored = set(s.tricks_scored)
    o.shown = set(s.shown)
    o.lock_record = dict(s.lock_record)
    o.observer = None                    # copies (bot lookahead, observe) never report to the replay
    if light:
        o.log = None
        o.stats = Counter()
    else:
        o.log = None if s.log is None else list(s.log)
        o.stats = Counter(s.stats)
    return o


def to_play(s):
    if s.phase == "over":
        return None
    if s.decision is not None:
        return s.decision["player"]
    return s.queue[s.pos]


def is_over(s):
    return s.phase == "over"


def legal_actions(s):
    if s.phase == "over":
        return []
    if s.decision is not None:
        return _decision_options(s)
    return _action_options(s, s.queue[s.pos])


def apply(s, action):
    if s.decision is not None:
        _apply_decision(s, action)
    else:
        _apply_action(s, action)
        s.pos += 1
    # the Past ends once its last action is done, and any rupture it caused has split
    if s.decision is None and s.phase in ("present", "past") and s.pos >= len(s.queue):
        if s.phase == "present":
            _start_past(s)
        if s.pos >= len(s.queue):
            begin_reveal(s)
    _advance(s)
    if s.cfg.check_invariants:
        check_invariants(s)


def begin_reveal(s):
    """End the Present and the Past now (bots use this to look ahead to the sweep)."""
    s.pos = len(s.queue)
    s.phase = "reveal"
    s.swept = set()
    s.tricks_scored = set()
    s.shown = set()
    for pl in s.players:
        pl.tricks = 0
    s.round_moves = {}
    s.locks_this_round = Counter()
    s.say(f"--- Round {s.round} reveal ---")


def run_until(s, policy, stop):
    """Drive the game with `policy(state, actions) -> action` until stop(s) or game over."""
    while s.phase != "over" and not stop(s):
        acts = legal_actions(s)
        apply(s, acts[0] if len(acts) == 1 else policy(s, acts))


# ----------------------------------------------------------------------------
# rounds
# ----------------------------------------------------------------------------

def _advance(s):
    if s.phase == "reveal":
        if not _continue_sweep(s):
            return
        s.phase = "lock"
        _lock_step(s)
        _finish_round(s)


def _finish_round(s):
    cfg = s.cfg
    b = s.board
    for _, _, c in b.all_cards():               # the present becomes the past
        c.zone = 0
    s.trick = {}
    for row in b.rows:
        if row.parent is not None and not row.locked:
            s.stats["branch_rounds"] += 1
            s.stats["branch_own_cards"] += sum(1 for c in row.cards if c.kind != Kind.PRESENT and not c.anchored)
    for _, _, c in b.all_cards():
        if c.kind == Kind.ANCESTOR and not c.pending:
            s.stats["ancestor_rounds"] += 1
            if len(c.marks) >= 2:
                s.stats["shared_ancestor_rounds"] += 1
    if s.log is not None:
        s.say(draw_board(s))
        s.say("Points: " + ", ".join(f"{pname(i)} {p.points}" for i, p in enumerate(s.players)))
    if s.winners:                               # someone reached locks_to_win in the lock step
        _end_game(s, "won", winner=s.winners[0])
        return
    if s.round >= cfg.round_limit:
        _end_game(s, "rounds")
        return
    _recycle_locked(s)
    if not b.active_rows():
        _fresh_timeline(s)
    s.round += 1
    s.first = (s.first + 1) % s.n
    _start_present(s)


def _recycle_locked(s):
    """A card that is no longer part of any open timeline goes back to the deck
    (through the discard pile), and its tokens and marker go home. History that
    an open timeline still runs through stays where it is."""
    b = s.board
    live = {b.card_at(r, i).uid for t in b.active_rows() for r, i in b.path(t)}
    gone = [c for _, _, c in b.all_cards()
            if c.uid not in live and c.kind != Kind.PRESENT and not c.anchored]
    for c in gone:
        _remove_card(s, c)
    if gone:
        s.stats["recycled"] += len(gone)
        s.stats["recycled_Ancestor"] += sum(c.kind == Kind.ANCESTOR for c in gone)
        s.say(f"(Sealed history: {len(gone)} card(s) no open timeline runs through go back to the deck.)")


def _fresh_timeline(s):
    """Every timeline is locked and nobody has won: a fresh timeline begins at
    the very start of history, sharing none, with the marker that has no suit.
    It gets its first trick next round, and can lock in that round's sweep."""
    b = s.board
    point = BoardCard(s.uid(), Kind.RUPTURE, None)
    point.anchored = True
    new = b.add_row(0, 0, [point, BoardCard(s.uid(), Kind.PRESENT, None)])
    s.row_created[new] = s.round
    s.stats["fresh_timelines"] += 1
    s.say(f"Every timeline is locked: a fresh timeline, T{new}, begins with no shared history.")


def _end_game(s, reason, winner=None):
    """The first to locks_to_win locks wins ("won"). After the round limit, most
    locks wins, and tied players share the win."""
    s.end_reason = reason
    best = max(p.points for p in s.players)
    s.winners = [winner] if winner is not None else [i for i in range(s.n) if s.players[i].points == best]
    s.phase = "over"
    s.decision = None
    s.say(f"=== Game over ({reason}) after {s.round} rounds: winner(s) "
          + ", ".join(pname(w) for w in s.winners) + " ===")
    s.say("Most signal markers on the board at once: "
          + ", ".join(f"{pname(p)} {pl.peak_markers}" for p, pl in enumerate(s.players)) + ".")


def lineage(s, t, p):
    """Player p's lineage on timeline t, along its whole path: the history it
    shares with other timelines counts too (D2)."""
    return s.board.tokens_on(t, p)


# ----------------------------------------------------------------------------
# the Present and the Past
#
# Each row is [history ...][trick cards (zone 1)][PRESENT]: the trick is drawn
# beyond the Present marker, and searches never cross between the two zones.
# At the end of the round every card returns to zone 0: the present becomes the past.
# ----------------------------------------------------------------------------

def _can_draw(s, p):
    if len(s.players[p].hand) >= s.cfg.hand_limit:
        return False
    return _deck_available(s)


def _can_recall(s, p):
    """Recall: in the Past, pay recall_cost to take any card from the (face-up)
    discard pile into hand. Not with hand_limit cards in hand, as for drawing.
    The charge adds to the instability, as a send's does, and can rupture the
    timeline whose Past it is."""
    pl = s.players[p]
    return bool(s.discard) and len(pl.hand) < s.cfg.hand_limit and pl.charge >= s.cfg.recall_cost


def _deck_available(s):
    return bool(s.deck) or bool(s.discard)


def _draw(s, p, quiet=False):
    if not s.deck:
        s.deck = s.discard
        s.discard = []
        s.rng.shuffle(s.deck)
        s.stats["reshuffles"] += 1
        s.say("(The discard pile is shuffled into a new deck.)")
    s.players[p].hand.append(s.deck.pop())
    if not quiet:
        s.say(f"{pname(p)} draws a card.")


def _start_present(s):
    """Refill every hand to (open timelines + hand_spare), then queue one trick card
    per player per open timeline. The lead rotates by round and by timeline."""
    s.phase = "present"
    rows = s.board.active_rows()
    s.actions_this_round = len(rows)
    target = max(1, len(rows)) + s.cfg.hand_spare
    for j in range(s.n):
        p = (s.first + j) % s.n
        while len(s.players[p].hand) < target and _deck_available(s):
            _draw(s, p, quiet=True)
    s.queue, s.queue_rows = [], []
    for idx, rid in enumerate(rows):
        lead = (s.first + idx) % s.n
        for j in range(s.n):
            s.queue.append((lead + j) % s.n)
            s.queue_rows.append(rid)
    s.trick_rows = list(rows)
    s.trick = {}
    s.pos = 0
    s.say(f"=== Round {s.round}: hands refilled to {target}; {len(rows)} trick(s); "
          f"{pname(s.first)} leads ===")
    if s.log is not None:
        s.say(draw_board(s))


def _start_past(s):
    """The Past: go across the timelines again. On each one, in order of tricks
    won last round (fewest first), every player may send one card back into that
    timeline's history (paying charge), draw one card, recall one, or pass. A
    send or recall can rupture the timeline (see _unsettle); the new timeline
    joins from the next round."""
    s.phase = "past"
    order = [(s.first + j) % s.n for j in range(s.n)]
    order.sort(key=lambda p: s.players[p].tricks)
    rows = [r for r in s.trick_rows if not s.board.rows[r].locked]
    s.queue = [p for _ in rows for p in order]
    s.queue_rows = [r for r in rows for _ in order]
    s.pos = 0
    s.say("--- The Past ---")


def _action_options(s, p):
    pl = s.players[p]
    if s.phase == "present":
        if pl.hand:
            return [("trick", k) for k in distinct(pl.hand)]
        return [("pass",)]
    via = s.queue_rows[s.pos]                    # the timeline whose past this action is for
    acts = [("draw",)] if _can_draw(s, p) else []
    if _can_recall(s, p):
        acts.extend(("recall", k) for k in distinct(s.discard))
    if pl.hand:
        kinds = distinct(pl.hand)
        for (rid, g), (cost, _) in sorted(past_gaps(s, via).items()):
            if cost <= pl.charge:
                acts.extend(("send", k, rid, g, via) for k in kinds)
    acts.append(("pass",))
    return acts


def _apply_action(s, a):
    p = s.queue[s.pos]
    pl = s.players[p]
    kind = a[0]
    s.stats["action_" + kind] += 1
    if kind == "draw":
        _draw(s, p)
    elif kind == "recall":
        k = a[1]
        if not _can_recall(s, p) or k not in s.discard:
            raise ValueError(a)
        via = s.queue_rows[s.pos]
        cost = s.cfg.recall_cost
        pl.charge -= cost
        s.discard.remove(k)
        pl.hand.append(k)
        s.stats["recalls"] += 1
        s.stats["recalled_" + NAMES[kind_of(k)]] += 1
        s.stats["charge_recall"] += cost
        if not can_rupture(s):
            s.stats["recalls_no_rupture"] += 1
        gauge = _add_instability(s, cost)
        s.say(f"{pname(p)} recalls {card_name(k)} from the discard pile for {cost} charge{gauge}.")
        _unsettle(s, p, via, "recall")
    elif kind == "send":
        _, k, rid, g, via = a
        branch = s.board.rows[rid].parent is not None
        s.stats["send_branch" if branch else "send_root"] += 1
        if len(s.board.timelines_through(rid, g)) > 1:
            s.stats["send_shared"] += 1
        if not branch and g == 0:
            s.stats["send_deepest"] += 1
        cost, jumped = past_gaps(s, via)[(rid, g)]
        pl.charge -= cost
        s.stats["charge_spent"] += cost
        if not can_rupture(s):
            s.stats["charge_spent_board_full"] += cost
        s.stats["past_sends"] += 1
        s.stats["past_jumped"] += jumped
        s.stats["past_jumped_max"] = max(s.stats["past_jumped_max"], jumped)
        pl.hand.remove(k)
        _place_marker(s, p)
        card = from_hand(k, s.uid(), p)
        s.board.insert(rid, g, card)
        s.stats["played_" + NAMES[card.kind]] += 1
        s.focus, s.hit = card.uid, None
        gauge = _add_instability(s, cost)
        s.say(f"{pname(p)} sends a card back into T{rid} gap {g} for {cost} charge{gauge} [{card_name(k)}].")
        _unsettle(s, p, via, "send")
    elif kind == "trick":
        _, k = a
        rid = s.queue_rows[s.pos]
        pl.hand.remove(k)
        _place_marker(s, p)
        card = from_hand(k, s.uid(), p)
        card.zone = 1
        row = s.board.rows[rid]
        s.board.insert(rid, len(row.cards) - 1, card)
        s.trick[card.uid] = {"origin": rid, "player": p}
        s.stats["played_" + NAMES[card.kind]] += 1
        s.stats["trick_cards"] += 1
        if card.suit is not None and card.suit == timeline_suit(s, rid):
            s.stats["trick_trumps_played"] += 1
        s.focus, s.hit = card.uid, None
        s.say(f"{pname(p)} plays a card into T{rid}'s present [{card_name(k)}].")
    elif kind == "pass":
        s.say(f"{pname(p)} passes.")
    else:
        raise ValueError(a)


def history_end(b, rid):
    """Index of the first card beyond row rid's Present marker: its first trick
    card, or the Present card itself."""
    cards = b.rows[rid].cards
    for i, c in enumerate(cards):
        if c.zone:
            return i
    return len(cards) - 1


def past_gaps(s, via=None):
    """Every history gap on timeline `via` (or on any open timeline, reached the
    cheapest way) -> (cost, cards jumped). Going back costs send_base for the
    newest gap, plus send_per_card for each history card passed (time steps)."""
    b = s.board
    best = {}
    for t in ([via] if via is not None else b.active_rows()):
        jumped, count = {}, 0
        for pos in reversed(b.path(t)):
            c = b.card_at(*pos)
            if c.zone or c.kind == Kind.PRESENT:
                jumped[pos] = 0
                continue
            if not c.anchored:
                count += 1
            jumped[pos] = count
        for rid, g in b.path_gaps(t):
            if g > history_end(b, rid):
                continue
            n = jumped.get((rid, g), 0)
            cost = s.cfg.send_base + s.cfg.send_per_card * n
            if (rid, g) not in best or cost < best[(rid, g)][0]:
                best[(rid, g)] = (cost, n)
    return best


def rupture_gaps(s, via):
    """Where timeline `via` can split when it ruptures: at any gap in its
    history, its shared part included, so the new timeline shares everything
    before that gap. Not at the very start of T0 (the new timeline must share
    some history), never right behind frozen history, and nowhere once there
    is no free Present marker or no room for another timeline (can_rupture)."""
    b = s.board
    if not can_rupture(s):
        return []
    return sorted((rid, g) for rid, g in b.path_gaps(via)
                  if (rid, g) != (0, 0) and g <= history_end(b, rid)
                  and not (g > 0 and b.card_at(rid, g - 1).frozen))


def split_threshold(s):
    """The instability at which a timeline ruptures: one round's income on one
    timeline (charge_win, plus charge_play for every other player), plus
    split_margin. 7 at 2 players, 8 at 3, 9 at 4."""
    cfg = s.cfg
    return cfg.charge_win + cfg.charge_play * (s.n - 1) + cfg.split_margin


def _score_tricks(s, upto):
    """When the sweep reaches a timeline's trick, every card in it turns face up
    and the trick is scored at once, before any of its own cards acts, on the
    cards in it right then, for whoever controls them. The best card wins even if
    it is killed or stolen straight afterwards. A trump (a card of the timeline's
    suit) beats every card that isn't; ties go to the card played first. Nothing
    reaches T0's trick before that, so it is scored as played; a later trick may
    have gained or lost a card to a Wormhole acting in an earlier one. The winner
    gains charge_win, everyone else who played into it charge_play. Scores every
    unscored trick up to timeline `upto` (None: all that are left)."""
    values = s.cfg.trick_values
    for rid in s.trick_rows:
        if rid in s.tricks_scored:
            continue
        if upto is not None and rid > upto:
            break
        s.tricks_scored.add(rid)
        trumps = timeline_suit(s, rid)
        cands = []
        for pos, c in enumerate(s.board.rows[rid].cards):
            if not c.zone or c.owner is None:
                continue
            if c.pending:
                c.pending = False                # turned face up to score; it still acts when the sweep reaches it
                s.shown.add(c.uid)
            trump = c.suit is not None and c.suit == trumps
            cands.append((trump, values.get(c.kind, 0), -pos, c.owner, c.kind, c.suit))
        played = {m["player"] for m in s.trick.values() if m["origin"] == rid}
        best = max(cands, default=None)
        winner = None if best is None else best[3]
        shown = ", ".join(f"{pname(c[3])} {_card_label(c[4], c[5])}" for c in cands)
        if winner is not None:
            s.players[winner].charge += s.cfg.charge_win
            s.players[winner].tricks += 1
            s.stats["charge_earned"] += s.cfg.charge_win
            s.stats["tricks_won"] += 1
            s.stats["trick_won_by_" + NAMES[best[4]]] += 1
            if best[0]:
                s.stats["tricks_won_by_trump"] += 1
                if any(not c[0] and c[1] > best[1] for c in cands):
                    s.stats["tricks_trump_beat_higher"] += 1
            if sum(1 for c in cands if c[:2] == best[:2]) > 1:
                s.stats["tricks_won_on_tie"] += 1
            if winner not in played:
                s.stats["tricks_won_by_outsider"] += 1
        else:
            s.stats["tricks_empty"] += 1
        for p in played:
            if p != winner:
                s.players[p].charge += s.cfg.charge_play
                s.stats["charge_earned"] += s.cfg.charge_play
        s.say(f"T{rid}'s trick is played: {shown or 'no cards'}. " +
              (f"{pname(winner)} wins with {_card_label(best[4], best[5])}{' (trump)' if best[0] else ''} "
               f"(+{s.cfg.charge_win} charge)" if winner is not None else "Nobody wins it")
              + (f"; +{s.cfg.charge_play} to " + ", ".join(pname(p) for p in sorted(played) if p != winner)
                 if s.cfg.charge_play and played - {winner} else "") + ".")


def _card_label(kind, suit):
    return card_name(kind if suit is None else Card(kind, suit))


# ----------------------------------------------------------------------------
# the sweep
# ----------------------------------------------------------------------------

def _immune(s, c):
    """The Present marker and split points can't be struck, stolen or moved."""
    return c.kind == Kind.PRESENT or c.anchored


def _back(s, card):
    """Whether this card's look back crosses the Present marker. Only a trick
    card's does, so a trick's first card is next to the last card of history;
    history never reaches forward into a trick."""
    return card.zone == 1


def _next_unswept(s):
    """Earliest card this round's sweep hasn't reached yet: every timeline's
    history first (by column, the older timeline first on a tie), and then the
    tricks, one whole timeline at a time. Present cards, split points and frozen
    cards never activate."""
    b = s.board
    best = None
    for row in b.rows:
        start = b.start(row.rid)
        for i, c in enumerate(row.cards):
            if c.kind == Kind.PRESENT or c.anchored or c.frozen or c.uid in s.swept:
                continue
            key = (1, row.rid, start + i) if c.zone else (0, start + i, row.rid)
            if best is None or key < best[0]:
                best = (key, row.rid, i, c)
    return None if best is None else best[1:]


def _continue_sweep(s):
    """Replay every timeline earliest-first. New cards flip as they are reached
    and act once; an Ancestor's controller may activate it every round; a
    trick is scored as the sweep reaches it. Returns True when the sweep is done,
    False if it stopped for a decision."""
    while s.decision is None:
        nxt = _next_unswept(s)
        if nxt is None:
            _score_tricks(s, None)
            return True
        rid, i, card = nxt
        if card.zone and rid not in s.tricks_scored:
            _score_tricks(s, rid)                    # the trick is settled before any card in it acts
        s.swept.add(card.uid)
        s.focus, s.hit = card.uid, None
        first = card.pending or card.uid in s.shown
        if card.pending:
            card.pending = False
            s.say(f"Reveal T{rid} col {drawn_col(s, rid, i)}: {cname(card)}.")
        elif first:
            s.say(f"Sweep T{rid} col {drawn_col(s, rid, i)}: {cname(card)}.")
        if card.kind == Kind.SENTINEL:
            continue
        if card.kind != Kind.ANCESTOR:               # every other card acts once, as it flips
            one_shot = card.kind in ONE_SHOT
            if one_shot and not first:
                continue
            _resolve(s, card)
            if one_shot and not _held(s, card):
                _discard_event(s, card)              # D13: used up; its marker goes home
            continue
        if s.players[card.owner].supply <= 0 or card.marks.get(card.owner, 0) >= 1:
            s.stats["no_target_Ancestor"] += 1       # one lineage per player per Ancestor
            continue
        if not first:
            s.say(f"Sweep T{rid} col {drawn_col(s, rid, i)}: {cname(card)}.")
        s.decision = {"type": "activate", "player": card.owner, "card": card.uid}
    return False


def _resolve(s, card):
    k = card.kind
    if k == Kind.ANCESTOR:
        _ancestor(s, card)
    elif k == Kind.ASSASSIN:
        _assassin(s, card)
    elif k == Kind.REVISIONIST:
        _revisionist(s, card)
    elif k == Kind.PROPHET:
        _prophet(s, card)
    elif k == Kind.WORMHOLE:
        _wormhole(s, card)
    elif k == Kind.EXECUTIONER:
        _executioner(s, card)
    elif k == Kind.USURPER:
        _usurper(s, card)
    elif k == Kind.COURIER:
        _courier(s, card)


def _place_marker(s, p):
    pl = s.players[p]
    pl.markers += 1
    pl.peak_markers = max(pl.peak_markers, pl.markers)
    s.stats["peak_markers"] = max(s.stats["peak_markers"], pl.markers)


def _return_pieces(s, card):
    if card.owner is not None:
        s.players[card.owner].markers -= 1
    for p, n in card.marks.items():
        s.players[p].supply += n
    card.marks = {}


def _remove_card(s, card):
    rid, i = s.board.find(card.uid)
    s.board.remove(rid, i)
    _return_pieces(s, card)
    s.discard.append(as_held(card))


def _kill(s, card, killer, weapon="Assassin"):
    was_pending = card.pending
    own = card.owner == killer
    s.hit = card.uid
    if card.uid in s.trick:
        s.stats["trick_kills"] += 1
    elif card.zone == 0:
        s.stats["history_kills"] += 1
    _remove_card(s, card)
    s.stats["kills"] += 1
    s.stats["killed_" + NAMES[card.kind]] += 1
    if own:
        s.stats["kills_own_card"] += 1
    whose = f"its own side's {NAMES[card.kind]}" if own else cname(card)
    if was_pending:
        s.stats["kills_pending"] += 1
        s.say(f"  {pname(killer)}'s {weapon} kills a pending card: {whose} never happens.")
    else:
        s.say(f"  {pname(killer)}'s {weapon} kills {whose}.")


def _convert(s, card, new_owner, by=None):
    """A steal: the card changes hands, and its marker with it. Everyone keeps
    their lineage tokens on it; the new controller can add theirs (D16)."""
    if card.owner is None or card.owner == new_owner:
        return False
    old = card.owner
    before = public(card)
    s.hit = card.uid
    s.players[old].markers -= 1
    _place_marker(s, new_owner)
    card.owner = new_owner
    s.stats["conversions"] += 1
    s.stats["converted_" + NAMES[card.kind]] += 1
    if by is not None:
        s.stats[f"hit:{NAMES[by]}>{NAMES[card.kind]}"] += 1
    s.say(f"  {before} is converted to {pname(new_owner)}"
          + (" (still pending)" if card.pending else "") + ".")
    return True


def _fizzle(s, card):
    s.stats["fizzle_" + NAMES[card.kind]] += 1
    s.say("  No effect.")


def _guards(s, c, striker, struck=False, target=None):
    """Whether card c is a Sentinel able to stop this striker right now. A
    struck Sentinel is immune to anyone's strike. A Sentinel merely beside the
    striker only shields its owner's card, and never from its owner's own
    strike: it stops the blow only if `target` is its owner's."""
    if not struck:
        if c.owner == striker.owner:
            return False
        if target is None or target.owner != c.owner:
            return False
    return c.kind == Kind.SENTINEL and not c.frozen


def _caught(s, sentinel, weapon="Assassin"):
    s.stats["sentinel_blocks"] += 1
    s.stats[f"hit:Sentinel>{weapon}"] += 1
    sentinel.pending = False                     # a facedown Sentinel turns face up
    s.hit = sentinel.uid
    s.say(f"  {cname(sentinel)} catches the {weapon}.")


def _count_hit(s, t, me, weapon="Assassin"):
    s.stats[f"hit:{weapon}>{NAMES[t.kind]}"] += 1
    if t.kind == Kind.ANCESTOR:
        if len(t.marks) >= 2:
            s.stats["shared_ancestor_kills"] += 1
        if t.marks.get(me):
            s.stats["kills_own_lineage"] += 1
        s.stats["lineage_destroyed"] += t.tokens


def _assassin(s, card):
    """Kill the next card, whoever owns it (the first card in each branch at a
    fork) (D19). A rival's Sentinel directly before the Assassin shields its
    owner's card from the blow; a Sentinel it strikes survives (D20). The sweep
    then discards the Assassin."""
    me = card.owner
    b = s.board
    rid, i = b.find(card.uid)
    prev = b.search_left(rid, i, lambda c: not c.anchored, cross=_back(s, card))
    guard = b.card_at(*prev) if prev is not None else None
    targets = [b.card_at(r, j) for r, j in b.search_right(rid, i, first_only=True, skip=_see_through(s))]
    targets = [t for t in targets if not t.frozen and not _immune(s, t)]
    if not targets:
        _fizzle(s, card)
        return
    targets.sort(key=lambda t: t.kind != Kind.WORMHOLE)   # a struck Wormhole acts before anything else is hit
    for t in targets:
        if guard is not None and _guards(s, guard, card, target=t):
            _caught(s, guard)                          # it shields its owner's card from this blow
            continue
        if _guards(s, t, card, struck=True):
            _caught(s, t)
            continue
        if _wormhole_reacts(s, t, card, "Assassin"):
            return
        _count_hit(s, t, me)
        _kill(s, t, me)


def _held(s, striker):
    """Whether this striker's blow is waiting on a struck Wormhole's move."""
    d = s.decision
    return d is not None and d.get("then", (None,))[0] == striker.uid


def _wormhole_reacts(s, t, striker, weapon):
    """A Wormhole struck by an Assassin or Executioner isn't killed. It turns
    face up and acts at once for its owner: it can move the striker itself, or
    the card on its other side. Then the strike lands on whatever is next to the
    striker now (not until a later trick it was moved into is scored). Returns
    True if it took over the strike."""
    if t.kind != Kind.WORMHOLE or t.frozen or t.owner is None:
        return False
    t.pending = False
    s.hit = t.uid
    s.swept.add(t.uid)
    s.stats["wormhole_reactions"] += 1
    s.say(f"  The {weapon} strikes {cname(t)}, which acts at once.")
    _wormhole(s, t)
    if s.decision is not None and s.decision["type"] == "wormhole":
        s.decision["then"] = (striker.uid, weapon)
        return True
    _strike_again(s, striker, weapon)          # nothing it could move: the blow carries on
    return True


def _strike_again(s, striker, weapon):
    """The striker's blow lands from wherever it is now."""
    if weapon == "Executioner":
        _executioner(s, striker)               # discards itself unless held again
    else:
        _assassin(s, striker)


def _waits_for_scoring(s, card):
    """No card acts in a trick before that trick is scored. So a striker that a
    struck Wormhole has moved into a later timeline's trick, still waiting its
    turn, holds its blow. Moved into a trick already scored (or within its own),
    it strikes at once."""
    if not card.zone:
        return False
    rid, _ = s.board.find(card.uid)
    return rid in s.trick_rows and rid not in s.tricks_scored


def _wait_for_scoring(s, card):
    """The held striker counts when its new trick is scored, then strikes when
    the sweep reaches it there, like any other card in that trick."""
    s.swept.discard(card.uid)
    s.shown.add(card.uid)                      # face up, but it hasn't acted yet
    s.stats["strikes_waiting"] += 1
    rid, _ = s.board.find(card.uid)
    s.say(f"  {cname(card)} waits until T{rid}'s trick is scored.")


def _executioner(s, card):
    """The Assassin's mirror: kill the previous card, whoever owns it. A rival's
    Sentinel directly after it shields its owner's card; a Sentinel it strikes
    is immune. Leading a trick, it hits the last card of history. Then it is
    discarded."""
    me = card.owner
    b = s.board
    rid, i = b.find(card.uid)
    hit = b.search_left(rid, i, lambda c: not c.anchored, cross=_back(s, card))
    target = b.card_at(*hit) if hit is not None else None
    after = [b.card_at(r, j) for r, j in b.search_right(rid, i, first_only=True, skip=_see_through(s))]
    guard = next((c for c in after if _guards(s, c, card, target=target)), None)
    if guard is not None:
        _caught(s, guard, "Executioner")
    elif target is None or target.frozen or _immune(s, target):
        _fizzle(s, card)
    elif _guards(s, target, card, struck=True):
        _caught(s, target, "Executioner")
    else:
        if _wormhole_reacts(s, target, card, "Executioner"):
            return
        _count_hit(s, target, me, "Executioner")
        _kill(s, target, me, "Executioner")
    _discard_event(s, card)


def _behind(s, rid, i, fits, cross=False):
    """The card a backward-acting card targets: the card directly behind it if
    that one fits, else nothing (split points are passed over)."""
    b = s.board
    hit = b.search_left(rid, i, lambda c: not c.anchored, cross=cross)
    return hit if hit is not None and fits(b.card_at(*hit)) else None


def _usurper(s, card):
    """Remove one rival's lineage token from the Ancestor directly behind it.
    The owner picks whose, if there's a choice, and the token goes home. Then
    the Usurper is discarded."""
    me = card.owner
    b = s.board
    rid, i = b.find(card.uid)
    hit = _behind(s, rid, i, lambda c: c.kind == Kind.ANCESTOR and not c.frozen
                  and any(p != me for p in c.marks), cross=_back(s, card))
    _discard_event(s, card)
    if hit is None:
        _fizzle(s, card)
        return
    anc = b.card_at(*hit)
    rivals = sorted(p for p in anc.marks if p != me)
    if len(rivals) == 1:
        _do_usurp(s, me, anc, rivals[0])
    else:
        s.decision = {"type": "usurp", "player": me, "card": anc.uid, "options": rivals}


def _do_usurp(s, me, anc, p):
    anc.mark(p, -1)
    s.players[p].supply += 1
    s.hit = anc.uid
    s.stats["usurped"] += 1
    if p == anc.owner:
        s.stats["usurped_controller"] += 1        # the controller can add it back next sweep
    s.say(f"  {pname(me)}'s Usurper removes {pname(p)}'s lineage from {public(anc)}.")


def _courier(s, card):
    """Its owner may play a card from their hand facedown straight after it (in
    its place, once it is discarded). That card acts later in this same sweep,
    and joins the trick if the Courier was in one."""
    me = card.owner
    rid, i = s.board.find(card.uid)
    zone = card.zone
    _discard_event(s, card)
    pl = s.players[me]
    if not pl.hand:
        _fizzle(s, card)
        return
    s.decision = {"type": "courier", "player": me, "row": rid, "gap": i, "zone": zone}


def _do_courier(s, d, k):
    p, rid = d["player"], d["row"]
    pl = s.players[p]
    pl.hand.remove(k)
    _place_marker(s, p)
    card = from_hand(k, s.uid(), p)
    card.zone = d["zone"]
    s.board.insert(rid, d["gap"], card)
    if card.zone:                                 # it joins the trick, as the latest card played
        s.trick[card.uid] = {"origin": rid, "player": p}
    s.stats["couriered_" + NAMES[card.kind]] += 1
    s.focus, s.hit = card.uid, None
    s.say(f"  {pname(p)} delivers a facedown card into T{rid} [{card_name(k)}].")


def _revisionist(s, card):
    """Steal the card directly behind it, if it's a rival's."""
    me = card.owner
    b = s.board
    rid, i = b.find(card.uid)
    hit = _behind(s, rid, i, lambda c: c.owner is not None and c.owner != me
                  and not c.frozen and not _immune(s, c), cross=_back(s, card))
    if hit is None or not _convert(s, b.card_at(*hit), me, by=Kind.REVISIONIST):
        _fizzle(s, card)


def _prophet(s, card):
    """Steal the next card (the first in each branch at a fork), whoever owns it."""
    me = card.owner
    b = s.board
    rid, i = b.find(card.uid)
    any_hit = False
    for r, j in b.search_right(rid, i, first_only=True, skip=_see_through(s)):
        t = b.card_at(r, j)
        if t.frozen or _immune(s, t):
            continue
        any_hit |= _convert(s, t, me, by=Kind.PROPHET)
    if not any_hit:
        _fizzle(s, card)


def _discard_event(s, card):
    _remove_card(s, card)


# ----- the Wormhole (D14) ---------------------------------------------------

def _movable(s, c):
    return not c.frozen and not c.anchored and not _immune(s, c)


def _see_through(s):
    return lambda c: c.anchored and _immune(s, c)


def _across_dest(s, x, t):
    """Where card x lands if moved across to timeline t: it only ever swaps,
    with the card in the equivalent timeslot. Returns that card's (row, index),
    or None for no move.
    - In a trick, that's the card in the same place in t's trick.
    - In history, count the cards after the point where the two timelines diverged
      (the last history they share). A split point marks a split; it isn't a
      timeslot. The card as many cards along t's path is the one. The count stops
      at t's Present marker, so nothing swaps from the past into the present.
    It may be in history t shares with another timeline. No card there, or one
    that can't move: no move."""
    b = s.board
    xpos = b.find(x.uid)
    if x.zone:
        if t not in s.trick_rows:
            return None
        mine = [c for c in b.rows[xpos[0]].cards if c.zone]
        theirs = [j for j, c in enumerate(b.rows[t].cards) if c.zone]
        k = mine.index(x)
        if k >= len(theirs) or not _movable(s, b.rows[t].cards[theirs[k]]):
            return None
        return (t, theirs[k])
    mine, theirs = b.path(xpos[0]), b.path(t)
    d = 0
    while d < min(len(mine), len(theirs)) and mine[d] == theirs[d]:
        d += 1
    if xpos not in mine[d:]:
        return None                              # t shares this card already
    count = sum(1 for p in mine[d:mine.index(xpos)] if not b.card_at(*p).anchored)
    for pos in theirs[d:]:
        y = b.card_at(*pos)
        if y.zone or y.kind == Kind.PRESENT:
            return None                          # t's history runs out first
        if y.anchored:
            continue
        if count == 0:
            return pos if _movable(s, y) else None
        count -= 1
    return None


def _wormhole_options(s, x):
    b = s.board
    xr, xi = b.find(x.uid)
    opts = []
    prev = b.search_left(xr, xi, lambda c: not c.anchored)
    if prev is not None and _movable(s, b.card_at(*prev)):
        opts.append(("wormhole", "down", None))
    for r, j in b.search_right(xr, xi, first_only=True, skip=_see_through(s)):
        if _movable(s, b.card_at(r, j)):
            opts.append(("wormhole", "up", r))
    on_path = set(b.timelines_through(xr, xi))
    for t in b.active_rows():
        if t not in on_path and _across_dest(s, x, t) is not None:
            opts.append(("wormhole", "across", t))
    return opts


def _wormhole(s, card):
    """The card directly before or after the Wormhole (the owner's choice) may
    move one slot down (earlier), one slot up (later; pick the branch at a fork),
    or across to the equivalent timeslot on another timeline. The Wormhole is
    used up either way."""
    b = s.board
    rid, i = b.find(card.uid)
    targets = []
    hit = b.search_left(rid, i, lambda c: not c.anchored, cross=_back(s, card))
    if hit is not None:                          # a history card it reaches back to stays in history
        targets.append((b.card_at(*hit), "before"))
    targets.extend((b.card_at(r, j), "after")    # the card after hasn't acted yet: it can be redirected
                   for r, j in b.search_right(rid, i, first_only=True, skip=_see_through(s)))
    owner = card.owner
    _discard_event(s, card)
    opts, sides = [], {}
    for x, side in targets:
        if _movable(s, x):
            moves = _wormhole_options(s, x)
            opts.extend(o + (x.uid,) for o in moves)
            if moves:
                sides[x.uid] = side
    if not opts:
        _fizzle(s, card)
        return
    s.decision = {"type": "wormhole", "player": owner, "options": opts, "sides": sides}


def _do_wormhole(s, x, move, target, mover=None):
    b = s.board
    xpos = b.find(x.uid)
    shared_before = len(b.timelines_through(*xpos))
    if move == "down":
        ypos = b.search_left(*xpos, lambda c: not c.anchored)
        y = b.card_at(*ypos)
        b.swap(xpos, ypos)
        where = f"down past {public(y)}"
    elif move == "up":
        ypos = next(p for p in b.search_right(*xpos, first_only=True, skip=_see_through(s))
                    if p[0] == target)
        y = b.card_at(*ypos)
        b.swap(xpos, ypos)
        where = f"up past {public(y)}"
    else:
        pos = _across_dest(s, x, target)
        y = b.card_at(*pos)
        b.swap(xpos, pos)
        where = f"across to T{target}, swapping with {public(y)}"
    s.stats["wormhole_" + move] += 1
    s.stats[f"hit:Wormhole>{NAMES[x.kind]}"] += 1
    shared_after = len(b.timelines_through(*b.find(x.uid)))
    if shared_after > shared_before:
        s.stats["wormhole_into_shared"] += 1
    elif shared_after < shared_before:
        s.stats["wormhole_out_of_shared"] += 1
    if mover is not None:
        s.stats["wormhole_own_card" if x.owner == mover else "wormhole_enemy_card"] += 1
        if s.round_moves.get(x.uid) == mover:
            s.stats["wormhole_combos"] += 1          # same player moved the same card twice this round
        s.round_moves[x.uid] = mover
    s.hit = x.uid
    s.say(f"  Wormhole moves {public(x)} {where}.")


# ----- the rupture ------------------------------------------------------------

def _add_instability(s, cost):
    """Charge spent on a send or a recall adds to the instability, but only
    while a rupture is possible: with no room, it doesn't move. Returns the
    gauge for the log line ("" with no room)."""
    if not can_rupture(s):
        return ""
    s.instability += cost
    return f" (instability {s.instability} of {split_threshold(s)})"


def _unsettle(s, p, via, cause="send"):
    """After player p's send or recall in timeline `via`'s Past has added its
    cost to the instability: if that reaches split_threshold, `via` ruptures at
    once, and p chooses where it splits. The instability goes back to 0: nothing
    carries over. With nowhere to split, nothing happens and the counter stays
    full, so the next send or recall ruptures. While can_rupture says no, spending
    doesn't add to the instability at all (see _add_instability), so it can't
    build up past the threshold."""
    total, threshold = s.instability, split_threshold(s)
    if total < threshold or not can_rupture(s):
        return
    gaps = rupture_gaps(s, via)
    if not gaps:
        s.stats["rupture_no_gap"] += 1
        s.say(f"Instability {total} of {threshold}, but T{via} has nowhere to split: the next send or recall ruptures.")
        return
    s.stats["instability_lost"] += total - threshold    # the excess over the threshold, which no longer carries over
    s.instability = 0
    s.say(f"Instability reaches {threshold}: T{via} ruptures, and {pname(p)} chooses where it splits.")
    s.decision = {"type": "split", "player": p, "via": via, "options": gaps, "cause": cause}


def _rupture(s, p, rid, g, via):
    """Timeline `via` ruptures at gap g of row rid, where player p chose: the new
    timeline shares everything before the gap, and the lineage on it. A neutral
    split point starts it, then its own Present, and nothing else: it gets its
    first trick next round, and can't lock this round. p chooses its suit."""
    b = s.board
    s.stats["ruptures"] += 1
    if "first_rupture_round" not in s.stats:
        s.stats["first_rupture_round"] = s.round
    x = b.card_at(rid, g - 1) if g > 0 else None
    point = BoardCard(s.uid(), Kind.RUPTURE, None)
    point.anchored = True
    new = b.add_row(rid, g, [point, BoardCard(s.uid(), Kind.PRESENT, None)])
    s.row_created[new] = s.round
    s.focus, s.hit = point.uid, None
    where = ("at the very start, with no shared history" if x is None
             else f"where T{rid} split off" if x.anchored else f"after {public(x)}")
    s.say(f"{pname(p)} splits T{via}: new timeline T{new} splits off {where}.")
    if len(b.rows) >= total_cap(s):
        s.stats["board_full_round"] = s.round
        s.say(f"  That makes {len(b.rows)} timelines: no more ruptures.")
    elif len(b.active_rows()) >= s.cfg.timeline_cap:
        s.say(f"  {len(b.active_rows())} open timelines: no rupture until one locks.")
    left = free_suits(s, exclude=new)
    if len(left) > 1:
        s.decision = {"type": "suit", "player": p, "row": new, "options": left}
    elif left:
        _set_suit(s, new, left[0])


def _set_suit(s, row, suit):
    s.board.rows[row].cards[-1].suit = suit
    s.stats["suit_chosen"] += 1
    s.say(f"  T{row}'s Present takes " + ("the marker with no suit." if suit is None else f"{SUITS[suit]} {SUIT_NAMES[suit]}."))


def _ancestor(s, card):
    """Its controller puts one of their lineage tokens on it."""
    card.mark(card.owner)
    s.players[card.owner].supply -= 1
    s.stats["lineage"] += 1
    s.say(f"  {pname(card.owner)} puts a token on the Ancestor {label(card)}.")


# ----------------------------------------------------------------------------
# lock step
# ----------------------------------------------------------------------------

def eligible_locks(s, p):
    """Timelines player p may lock right now: tokens_to_secure lineage on it and
    strictly more than anyone else. Nothing locks before the first rupture, and
    a new timeline can't lock in the round it appears."""
    if len(s.board.rows) < 2:
        return []
    out = []
    for t in s.board.active_rows():
        if s.row_created.get(t) == s.round:
            continue
        counts = [lineage(s, t, q) for q in range(s.n)]
        mine = counts[p]
        if mine <= max(c for q, c in enumerate(counts) if q != p):
            continue
        if mine >= s.cfg.tokens_to_secure:
            out.append(t)
    return out


def _lock_step(s):
    """After the sweep, in turn order from the round's first player, every
    timeline that can lock does."""
    for j in range(s.n):
        p = (s.first + j) % s.n
        while True:
            options = eligible_locks(s, p)
            if not options:
                break
            _do_lock(s, p, options[0])
            if s.players[p].points >= s.cfg.locks_to_win:
                s.winners = [p]                  # the first to get there; the game ends as the round does
                return


def _do_lock(s, p, t):
    b = s.board
    s.lock_record[t] = {"player": p, "tally": [lineage(s, t, q) for q in range(s.n)]}
    s.players[p].points += 1
    b.rows[t].locked = True
    for r, i in b.path(t):
        b.card_at(r, i).frozen = True
    s.stats["locks"] += 1
    if "first_lock_round" not in s.stats:
        s.stats["first_lock_round"] = s.round
    s.locks_this_round[p] += 1
    if s.locks_this_round[p] == 2:
        s.stats["multi_locks"] += 1
    s.stats["max_locks_one_round"] = max(s.stats["max_locks_one_round"], s.locks_this_round[p])
    own = [c for c in b.rows[t].cards if c.kind != Kind.PRESENT and not c.anchored]
    if b.rows[t].parent is not None and not own:
        s.stats["empty_branch_locks"] += 1      # a branch with nothing of its own, won on shared history
    mine = [(c.owner, c.marks.get(p, 0)) for c in (b.card_at(r, i) for r, i in b.path(t))]
    s.stats["lock_lineage"] += sum(n for _, n in mine)
    s.stats["lock_lineage_on_others"] += sum(n for o, n in mine if o != p)
    s.say(f"{pname(p)} locks T{t}.")


# ----------------------------------------------------------------------------
# decisions
# ----------------------------------------------------------------------------

def _decision_options(s):
    d = s.decision
    if d["type"] == "activate":
        return [("activate", d["card"]), ("skip", d["card"])]
    if d["type"] == "wormhole":
        return d["options"] + [("wormhole", "stay", None, None)]
    if d["type"] == "split":
        return [("split", rid, g) for rid, g in d["options"]]
    if d["type"] == "suit":
        return [("suit", x) for x in d["options"]]
    if d["type"] == "usurp":
        return [("usurp", p) for p in d["options"]]
    if d["type"] == "courier":
        pl = s.players[d["player"]]
        return [("courier", k) for k in distinct(pl.hand)] + [("courier", None)]
    raise ValueError(d)


def _card_by_uid(s, uid):
    return s.board.card_at(*s.board.find(uid))


def _apply_decision(s, a):
    d = s.decision
    if d["type"] == "usurp":
        if a[1] not in d["options"]:
            raise ValueError(a)
        s.decision = None
        _do_usurp(s, d["player"], _card_by_uid(s, d["card"]), a[1])
    elif d["type"] == "courier":
        s.decision = None
        if a[1] is None:
            s.stats["courier_kept"] += 1
            s.say(f"  {pname(d['player'])} keeps their cards.")
        else:
            _do_courier(s, d, a[1])
    elif d["type"] == "split":
        if a[0] != "split" or (a[1], a[2]) not in d["options"]:
            raise ValueError(f"{a}: T{d['via']} can't split there")
        s.decision = None
        _rupture(s, d["player"], a[1], a[2], d["via"])
    elif d["type"] == "suit":
        if a[1] not in d["options"]:
            raise ValueError(f"{a}: that suit is taken")
        s.decision = None
        _set_suit(s, d["row"], a[1])
    elif d["type"] == "wormhole":
        s.decision = None
        if a[1] == "stay":
            s.stats["wormhole_stay"] += 1
            s.say("  The Wormhole leaves it where it is.")
        else:
            _do_wormhole(s, _card_by_uid(s, a[3]), a[1], a[2], mover=d["player"])
        if d.get("then"):                        # a struck Wormhole has moved: now the blow lands
            uid, weapon = d["then"]
            striker = _card_by_uid(s, uid)
            if _waits_for_scoring(s, striker):   # ...unless it's now in a trick still waiting its turn
                _wait_for_scoring(s, striker)
            else:
                _strike_again(s, striker, weapon)
                if weapon == "Assassin" and not _held(s, striker):
                    _discard_event(s, striker)
    elif d["type"] == "activate":
        s.decision = None
        card = _card_by_uid(s, d["card"])
        if a[0] == "activate":
            s.stats["activated_" + NAMES[card.kind]] += 1
            s.say(f"  {pname(card.owner)} activates {NAMES[card.kind]}.")
            _resolve(s, card)
        else:
            s.stats["skipped_" + NAMES[card.kind]] += 1
    else:
        raise ValueError(d)


# ----------------------------------------------------------------------------
# hidden information
# ----------------------------------------------------------------------------

def observe(s, p):
    """A copy of the state as player p sees it: other hands, the deck and other
    players' facedown cards are replaced by Kind.UNKNOWN."""
    o = clone(s)
    o.log = None
    for q, pl in enumerate(o.players):
        if q != p:
            pl.hand = [Kind.UNKNOWN] * len(pl.hand)
    o.deck = [Kind.UNKNOWN] * len(o.deck)
    for _, _, c in o.board.all_cards():
        if c.pending and c.owner != p:
            c.kind = Kind.UNKNOWN
            c.suit = None
    o.rng = random.Random(0)
    return o


# ----------------------------------------------------------------------------
# invariants
# ----------------------------------------------------------------------------

def check_invariants(s):
    cfg = s.cfg
    b = s.board
    on_board_tokens = [0] * s.n
    on_board_markers = [0] * s.n
    board_cards = 0
    for row in b.rows:
        assert row.cards and row.cards[-1].kind == Kind.PRESENT, f"T{row.rid} must end in a Present"
        assert sum(c.kind == Kind.PRESENT for c in row.cards) == 1, f"T{row.rid} has extra Presents"
        zones = [c.zone for c in row.cards[:-1]]
        assert zones == sorted(zones) and not row.cards[-1].zone, f"T{row.rid}: history after a trick card"
        assert not any(zones) or s.phase in ("present", "past", "reveal", "lock"), "trick cards outside a round"
        if row.parent is not None:
            parent = b.rows[row.parent]
            assert 0 <= row.k <= len(parent.cards) - 1, f"T{row.rid} k out of range"
            assert row.cards[0].anchored, f"T{row.rid} lost its split point"
        for c in row.cards:
            if c.kind == Kind.PRESENT:
                assert c.owner is None and not c.marks
                continue
            if not c.anchored:
                board_cards += 1                 # a split point is a marker, not a card from the deck
            assert c.owner is not None or c.anchored, "only Present markers and split points are neutral"
            for p, n in c.marks.items():
                on_board_tokens[p] += n
                assert n == 1, "one lineage per player per Ancestor"
            if c.owner is None:
                assert not c.marks
                continue
            on_board_markers[c.owner] += 1
            if c.pending:
                assert s.phase in ("present", "past", "reveal"), "facedown card outside the Present, Past or sweep"
    for p, pl in enumerate(s.players):
        assert pl.supply + on_board_tokens[p] == cfg.token_supply, f"{pname(p)} token leak"
        assert pl.markers == on_board_markers[p], f"{pname(p)} marker leak"
        assert pl.markers <= pl.peak_markers
        assert pl.supply >= 0 and pl.charge >= 0
    assert s.instability >= 0, "negative instability"
    choosing = s.decision["row"] if s.decision is not None and s.decision["type"] == "suit" else None
    markers = [row.cards[-1].suit for row in b.rows if not row.locked and row.rid != choosing]
    assert len(markers) == len(set(markers)), "two open timelines share a Present marker"
    assert len([r for r in b.rows if not r.locked]) <= s.cfg.timeline_cap, "too many open timelines"
    assert len(b.rows) <= total_cap(s), "too many timelines"
    hands = sum(len(pl.hand) for pl in s.players)
    assert hands + len(s.deck) + len(s.discard) + board_cards == s.deck_total, "card leak"
    for row in b.rows:
        if row.locked:
            for r, i in b.path(row.rid):
                assert b.card_at(r, i).frozen, "unfrozen card on a locked path"
