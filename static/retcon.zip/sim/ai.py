"""Shared AI pieces: a position evaluator, a quick decision policy for lookahead,
and guessing the cards a player can't see."""

import random
from collections import Counter
from dataclasses import dataclass, replace

from . import engine
from .cards import Kind, build_deck, kind_of, suit_of


@dataclass
class Weights:
    point: float = 40.0        # a locked timeline
    anchor: float = 3.0        # per lineage token on a timeline's path (shared ones count per timeline)
    lead: float = 3.0          # strictly most lineage on a timeline
    secure: float = 8.0        # at or past the lock threshold with the lead
    ancestor: float = 3.0          # a controlled Ancestor on the board (future lineage)
    ancestor_room: float = 1.0     # if it doesn't carry my lineage yet
    assassin: float = 2.5
    sentinel: float = 1.5
    charge: float = 1.0        # per unit of time charge, up to charge_cap
    charge_cap: int = 12
    charge_over: float = 0.0   # per unit of charge above charge_cap
    hand: float = 1.0          # per card in hand
    hand_ancestor: float = 0.0     # extra for each Ancestor in hand (a lineage still to place)
    opp: float = 0.8           # how much the strongest opponent's utility counts against us


def utility(s, p, w):
    b = s.board
    cfg = s.cfg
    need = cfg.tokens_to_secure
    pl = s.players[p]
    u = w.point * pl.points
    for t in b.active_rows():
        counts = [engine.lineage(s, t, q) for q in range(s.n)]
        a = counts[p]
        o = max(c for q, c in enumerate(counts) if q != p)
        u += w.anchor * min(a, need)
        if a > o:
            u += w.lead
            if a >= need:
                u += w.secure
    for _, _, c in b.all_cards():
        if c.owner != p or c.frozen:
            continue
        if c.kind == Kind.ANCESTOR:
            u += w.ancestor + w.ancestor_room * max(0, 1 - c.marks.get(p, 0))
        elif c.kind == Kind.ASSASSIN:
            u += w.assassin
        elif c.kind == Kind.SENTINEL:
            u += w.sentinel
    u += w.charge * min(pl.charge, w.charge_cap) + w.charge_over * max(0, pl.charge - w.charge_cap)
    u += w.hand * min(len(pl.hand), cfg.hand_limit)
    if w.hand_ancestor:
        u += w.hand_ancestor * sum(1 for c in pl.hand if kind_of(c) == Kind.ANCESTOR)
    return u


def value(s, me, w):
    if s.phase == "over":
        return 1000.0 / len(s.winners) if me in s.winners else -1000.0
    us = [utility(s, p, w) for p in range(s.n)]
    return us[me] - w.opp * max(u for q, u in enumerate(us) if q != me)


def outcome(s, me, w):
    """Like value, but an ended game also counts the margin on locks, then the
    position, so moves that don't change who wins still differ (in the last
    round, every move ends the game)."""
    us = [utility(s, p, w) for p in range(s.n)]
    edge = us[me] - w.opp * max(u for q, u in enumerate(us) if q != me)
    if s.phase != "over":
        return edge
    points = [p.points for p in s.players]
    margin = points[me] - max(x for q, x in enumerate(points) if q != me)
    return (1000.0 / len(s.winners) if me in s.winners else -1000.0) + 10 * margin + 0.01 * edge


# ----------------------------------------------------------------------------
# guessing what a player can't see
# ----------------------------------------------------------------------------

def unseen(view, me):
    """The cards player `me` hasn't seen: the whole deck less their hand, the
    discard pile and every card on the board they can see."""
    pool = Counter(build_deck(view.cfg.deck))
    seen = list(view.players[me].hand) + list(view.discard)
    seen += [engine.as_held(c) for _, _, c in view.board.all_cards()
             if c.kind not in (Kind.UNKNOWN, Kind.PRESENT) and not c.anchored]
    pool.subtract(seen)
    return [c for c, n in pool.items() for _ in range(n)]


def determinize(view, me, rng):
    """One guess at everything player `me` can't see, as a full state to play on:
    rivals' hands, rivals' facedown cards and the deck, dealt at random from the
    cards they haven't seen. No invariant checks or log in the copy."""
    s = engine.clone(view, light=True)
    s.cfg = replace(view.cfg, check_invariants=False, log=False)
    pool = unseen(view, me)
    rng.shuffle(pool)
    spare = build_deck(view.cfg.deck)              # only if the board was set up by hand

    def deal():
        return pool.pop() if pool else rng.choice(spare)
    for _, _, c in s.board.all_cards():
        if c.kind == Kind.UNKNOWN:
            card = deal()
            c.kind, c.suit = kind_of(card), suit_of(card)
    for q, pl in enumerate(s.players):
        if q != me:
            pl.hand = [deal() for _ in pl.hand]
    s.deck = [deal() for _ in s.deck]
    s.rng = random.Random(rng.random())
    return s


# ----------------------------------------------------------------------------
# quick decisions used inside lookahead (and by rule-based bots)
# ----------------------------------------------------------------------------

def quick_decision(s, actions, w):
    """Activation, Wormhole, a rupture's split and suit, and other mid-sweep choices without deep search."""
    kind = actions[0][0]
    if kind in ("activate", "skip"):
        return ("activate", actions[0][1])
    if kind == "split":
        me = engine.to_play(s)
        return max(actions, key=lambda a: split_edge(s, me, a[1], a[2]))
    if kind == "suit":
        return suit_choice(s, actions)
    if kind in ("wormhole", "usurp", "courier"):
        me = engine.to_play(s)
        return best_by_value(s, actions, me, w, finish=False)
    return actions[0]


def split_edge(s, me, rid, g):
    """My lead in lineage on the history a new timeline split at gap g of row
    rid would share (then my lineage there, then how late the split is)."""
    b = s.board
    tally = [0] * s.n
    for r, i in b.shared_prefix(rid) + [(rid, i) for i in range(g)]:
        for p, n in b.card_at(r, i).marks.items():
            tally[p] += n
    return tally[me] - max(n for p, n in enumerate(tally) if p != me), tally[me], g


def suit_choice(s, actions):
    """The brancher's suit for a new timeline: the one their hand is strongest in,
    counting Ancestors (which win tricks and score) double."""
    hand = s.players[s.decision["player"]].hand

    def strength(a):
        return sum(2 if kind_of(c) == Kind.ANCESTOR else 1 for c in hand if suit_of(c) == a[1])
    return max(actions, key=strength)


def best_by_value(s, actions, me, w, finish=True):
    best, best_v = None, None
    for a in actions:
        c = engine.clone(s, light=True)
        engine.apply(c, a)
        if finish:
            finish_round(c, w)
        v = value(c, me, w)
        if best_v is None or v > best_v:
            best, best_v = a, v
    return best


def finish_round(s, w, action_policy=None):
    """Play out the rest of the current round. Remaining actions use
    action_policy (default: end the Present and the Past now); decisions use quick_decision."""
    start = s.round
    if s.phase in ("present", "past") and action_policy is None:
        engine.begin_reveal(s)
        engine._advance(s)

    def policy(st, acts):
        if st.decision is not None:
            return quick_decision(st, acts, w)
        return action_policy(st, acts)

    engine.run_until(s, policy, lambda st: st.round != start)
