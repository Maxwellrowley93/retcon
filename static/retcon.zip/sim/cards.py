from enum import IntEnum
from typing import NamedTuple


class Kind(IntEnum):
    ANCESTOR = 0
    ASSASSIN = 1
    SENTINEL = 2
    REVISIONIST = 3
    PROPHET = 4
    RUPTURE = 7       # a split point: the neutral start of a timeline that ruptured off another
    PRESENT = 8       # a timeline's Present marker
    UNKNOWN = 9       # a card whose identity is hidden from the observer
    WORMHOLE = 10     # moves the card before or after it down, up or across (D14)
    EXECUTIONER = 11  # one-shot, kills the previous card (the Assassin's mirror)
    USURPER = 12      # one-shot, removes a rival's lineage token from the Ancestor behind it
    COURIER = 13      # one-shot, its owner plays a card from hand straight after it, mid-sweep


NAMES = {
    Kind.ANCESTOR: "Ancestor",
    Kind.ASSASSIN: "Assassin",
    Kind.SENTINEL: "Sentinel",
    Kind.REVISIONIST: "Revisionist",
    Kind.PROPHET: "Prophet",
    Kind.WORMHOLE: "Wormhole",
    Kind.RUPTURE: "Rupture",
    Kind.EXECUTIONER: "Executioner",
    Kind.USURPER: "Usurper",
    Kind.COURIER: "Courier",
    Kind.PRESENT: "PRESENT",
    Kind.UNKNOWN: "?",
}

# Every card has one of four suits, and so does every timeline's Present marker.
# A card of its timeline's suit is a trump in that timeline's trick. Suits do nothing else.
SUITS = ("♠", "♥", "♦", "♣")
SUIT_NAMES = ("Spades", "Hearts", "Diamonds", "Clubs")

DECK = {                   # cards per suit (♠, ♥, ♦, ♣): 52 cards, 13 a suit, every suit the same
    Kind.ANCESTOR: (3, 3, 3, 3),
    Kind.ASSASSIN: (1, 1, 1, 1),
    Kind.SENTINEL: (2, 2, 2, 2),
    Kind.REVISIONIST: (1, 1, 1, 1),
    Kind.PROPHET: (1, 1, 1, 1),
    Kind.WORMHOLE: (2, 2, 2, 2),
    Kind.EXECUTIONER: (1, 1, 1, 1),
    Kind.USURPER: (1, 1, 1, 1),
    Kind.COURIER: (1, 1, 1, 1),
}

TRICK_VALUES = {           # a card's strength in the trick at the Present (v1.0.1): the more a card
    Kind.ANCESTOR: 10,     # gives up by being played into a trick instead of sent back, the more it's worth here
    Kind.ASSASSIN: 8,
    Kind.SENTINEL: 7,
    Kind.PROPHET: 6,
    Kind.EXECUTIONER: 5,
    Kind.USURPER: 4,
    Kind.REVISIONIST: 3,
    Kind.WORMHOLE: 2,
    Kind.COURIER: 1,
}


class Card(NamedTuple):
    """A card as it sits in a hand, the deck or the discard pile."""
    kind: Kind
    suit: int


def kind_of(card):
    """A card's kind. A bare Kind stands for a card whose suit is unknown or
    doesn't matter (an observer's Kind.UNKNOWN, or a test's hand)."""
    return card.kind if isinstance(card, Card) else card


def suit_of(card):
    return card.suit if isinstance(card, Card) else None


def card_name(card):
    return NAMES[kind_of(card)] if suit_of(card) is None else f"{SUITS[card.suit]} {NAMES[card.kind]}"


def card_key(card):
    """Sort order for a hand: by kind, then suit."""
    s = suit_of(card)
    return (int(kind_of(card)), -1 if s is None else s)


def distinct(hand):
    """The different cards in a hand, in a stable order (one option each)."""
    return sorted(set(hand), key=card_key)


def build_deck(deck=None):
    """The cards of `deck` (kind -> count per suit), in a fixed order before shuffling."""
    out = []
    for kind, per in (DECK if deck is None else deck).items():
        for s, n in enumerate(per):
            out.extend([Card(Kind(kind), s)] * n)
    return out
