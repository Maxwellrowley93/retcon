from dataclasses import dataclass, field

from .cards import DECK, TRICK_VALUES


@dataclass
class Config:
    """The rules of Retcon v1.3.2 (RULES.md). Every setting is a number to tune;
    the rules themselves have no switches."""

    deck: dict = field(default_factory=lambda: dict(DECK))   # kind -> cards per suit (♠, ♥, ♦, ♣)
    trick_values: dict = field(default_factory=lambda: dict(TRICK_VALUES))   # kind -> strength in a trick
    hand_spare: int = 2                    # hands refill to one card per open timeline, plus this many
    hand_limit: int = 7                    # no drawing with this many cards in hand
    charge_win: int = 3                    # charge for winning a trick
    charge_play: int = 1                   # charge for every other player who played into that trick
    send_base: int = 1                     # charge to send a card just behind the Present marker
    send_per_card: int = 1                 # ...plus this for each history card it goes behind
    split_margin: int = 3                  # a timeline ruptures when the charge spent on sends, table-wide, reaches
                                           # one round's income on one timeline (charge_win + charge_play per other
                                           # player) plus this: 7 at 2 players, 8 at 3, 9 at 4
    recall_cost: int = 3                   # the Past: charge to take any card from the discard pile into hand
                                           # (it adds to the instability, as a send's charge does)
    starting_charge: int = 0
    tokens_to_secure: int = 3              # lineage on a timeline, with strictly the most, to lock it
    round_limit: int = 30                  # a safety cap: the game ends after this round, most locks winning
    timeline_cap: int = 5                  # open timelines at most: one per Present marker (no suit, ♠, ♥, ♦, ♣)
    locks_to_win: int = 3                  # the first player to lock this many timelines wins at once; there are
                                           # at most players x (locks_to_win - 1) + 1 timelines in all (7 at 3 players),
                                           # so someone must get there
    token_supply: int = 15                 # lineage tokens per player
    log: bool = False
    check_invariants: bool = False
