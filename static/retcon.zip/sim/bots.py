"""Bot players. Each bot only ever receives `observe(state, me)`, never the true state.

    RandomBot     uniform by action type, then uniform within the type
    RuleBot       fast, hand-written intent (Assassins in front of enemy Ancestors, ...);
                  `style` gives the archetypes: balanced, builder, aggressor,
                  manipulator, historian
    GreedyBot     one-move lookahead to the end of the round, treating opponents'
                  facedown cards as doing nothing (no prediction)
    PlannerBot    Greedy's search, but over guesses at the hidden cards, with the
                  rest of the round played out by every player
"""

import random

from . import ai, engine
from .cards import Kind, distinct, kind_of, suit_of


class RandomBot:
    name = "random"

    def __init__(self, seed=None):
        self.rng = random.Random(seed)

    def act(self, view, actions):
        by_type = {}
        for a in actions:
            by_type.setdefault(a[0], []).append(a)
        kind = self.rng.choice(sorted(by_type))
        return self.rng.choice(by_type[kind])


STYLE_PREFS = {
    "balanced":    {},
    "builder":     {Kind.ANCESTOR: 3, Kind.SENTINEL: 2, "other": 0.6},
    "aggressor":   {Kind.ASSASSIN: 3, Kind.REVISIONIST: 2.5, Kind.PROPHET: 2.5, Kind.ANCESTOR: 1, "other": 0.5},
    "manipulator": {Kind.WORMHOLE: 3, "other": 0.8},
    "historian":   {},
}


class RuleBot:
    """Plays each card where its effect is most obviously useful."""

    def __init__(self, seed=None, style="balanced", w=None):
        self.rng = random.Random(seed)
        self.style = style
        self.name = f"rule:{style}"
        self.prefs = STYLE_PREFS[style]
        self.w = w or ai.Weights()

    # -- helpers --------------------------------------------------------------

    @staticmethod
    def _ancestors(view, pred):
        me = engine.to_play(view)
        out = [(c.tokens - 2 * c.marks.get(me, 0), rid, i) for rid, i, c in view.board.all_cards()
               if c.kind == Kind.ANCESTOR and not c.frozen and not c.pending and pred(c.owner)]
        return [(rid, i) for _, rid, i in sorted(out, reverse=True)]

    def _targets(self, view, me, kind, legal_gaps):
        b = view.board
        enemy = self._ancestors(view, lambda o: o is not None and o != me)
        mine = self._ancestors(view, lambda o: o == me)
        shared = lambda g: (-len(b.timelines_through(*g)), b.col(g[0], min(g[1], len(b.rows[g[0]].cards) - 1)))
        if self.style == "historian":
            return sorted(legal_gaps, key=shared)
        if kind in (Kind.ASSASSIN, Kind.PROPHET):
            return [(r, i) for r, i in enemy]                 # directly in front of an enemy Ancestor
        if kind in (Kind.EXECUTIONER, Kind.USURPER):
            return [(r, i + 1) for r, i in enemy]             # directly behind an enemy Ancestor
        if kind == Kind.REVISIONIST:
            return [(r, i + 1) for r, i in enemy]             # directly behind an enemy Ancestor
        if kind == Kind.SENTINEL:
            return [(r, i) for r, i in mine]                  # shield my best Ancestor
        if kind == Kind.WORMHOLE:
            return [(r, i + 1) for r, i in mine]              # move my best Ancestor
        if kind == Kind.ANCESTOR:
            return sorted(legal_gaps, key=shared)             # deep, shared history
        return []

    # -- policy ---------------------------------------------------------------

    def _trick_card(self, view, actions):
        """Pick a card for the current trick by where it falls in it."""
        rid = view.queue_rows[view.pos]
        before = view.pos - view.queue_rows.index(rid)                 # cards already in this trick
        after = sum(1 for r in view.queue_rows[view.pos + 1:] if r == rid)
        values = view.cfg.trick_values
        trumps = view.board.rows[rid].cards[-1].suit
        me = engine.to_play(view)
        behind = None                                                   # leading, a card can reach back into history
        if not before:
            row = view.board.rows[rid]
            hit = view.board.search_left(rid, len(row.cards) - 1, lambda c: c.zone == 0 and not c.anchored, cross=True)
            behind = view.board.card_at(*hit) if hit is not None else None
        rival_behind = behind is not None and behind.owner not in (None, me) and not behind.frozen

        def score(card):
            k = kind_of(card)
            v = values.get(k, 0)
            if trumps is not None and suit_of(card) == trumps:
                v += max(values.values()) + 1                           # a trump beats every card that isn't
            if k in (Kind.ASSASSIN, Kind.PROPHET):
                v += 5 if after else -3                                 # they hit the next card
            elif k in (Kind.REVISIONIST, Kind.EXECUTIONER):
                v += 4 if before or rival_behind else -3               # it hits the one before
            elif k == Kind.COURIER:
                v += 3                                                  # it brings a second card
            elif k == Kind.ANCESTOR:
                v += 2
            return v * self.prefs.get(k, self.prefs.get("other", 1.0)) + 2 * self.rng.random()
        return max(actions, key=lambda a: score(a[1]))

    def _ancestor_gap(self, view, me, legal):
        """Where an Ancestor sent back now would help most: a gap whose new
        lineage gives me the lead, or 3 with the lead, on open timelines (one in
        shared history counts on each of them). None if no gap does either.
        legal: {(row, gap): cost}."""
        b = view.board
        need = view.cfg.tokens_to_secure
        best, best_score = None, 0.0
        for (rid, g), cost in legal.items():
            gain = 0
            for t in b.timelines_through(rid, g):
                if b.rows[t].locked:
                    continue
                counts = [engine.lineage(view, t, q) for q in range(view.n)]
                a = counts[me]
                o = max(c for q, c in enumerate(counts) if q != me)
                if a + 1 > o and a + 1 >= need:
                    gain += 3                       # a lock, if it survives the sweep
                elif a + 1 > o >= a:
                    gain += 2                       # takes or breaks a tie for the lead
            score = gain - 0.25 * cost
            if gain >= 2 and score > best_score:
                best, best_score = (rid, g), score
        return best

    def _past(self, view, actions):
        """The Past: send a card back if there's an obvious target (an Ancestor
        where its lineage takes the lead or reaches 3), else recall an Ancestor
        from the discard pile if I hold none and can spare the charge, else draw
        or pass. A send that ruptures the timeline splits it where I'd lead the
        new one (ai.quick_decision)."""
        me = engine.to_play(view)
        sends = [a for a in actions if a[0] == "send"]
        if sends:
            kinds = distinct(a[1] for a in sends)
            self.rng.shuffle(kinds)
            kinds.sort(key=lambda k: -self.prefs.get(kind_of(k), self.prefs.get("other", 1.0)))
            for kind in kinds:
                legal = {(a[2], a[3]): a for a in sends if a[1] == kind}
                if kind_of(kind) == Kind.ANCESTOR:
                    via = legal[next(iter(legal))][4]
                    costs = engine.past_gaps(view, via)
                    gap = self._ancestor_gap(view, me, {g: costs[g][0] for g in legal})
                    if gap is not None:
                        return legal[gap]
                    continue                                           # else keep it for a trick
                for t in self._targets(view, me, kind_of(kind), list(legal)):
                    if t in legal:
                        return legal[t]
        pl = view.players[me]
        recalls = [a for a in actions if a[0] == "recall" and kind_of(a[1]) == Kind.ANCESTOR]
        if (recalls and not any(kind_of(c) == Kind.ANCESTOR for c in pl.hand)
                and pl.charge >= view.cfg.recall_cost + 2):
            return self.rng.choice(recalls)
        if ("draw",) in actions and self.rng.random() < 0.7:
            return ("draw",)
        return ("pass",)

    def act(self, view, actions):
        if view.decision is not None:
            return ai.quick_decision(view, actions, self.w)
        return self._trick_card(view, actions) if actions[0][0] == "trick" else self._past(view, actions)


class GreedyBot:
    """Tries every legal move, plays the round out to the end with opponents'
    hidden cards inert, and keeps the best-scoring move."""

    name = "greedy"

    def __init__(self, seed=None, w=None, max_candidates=60):
        self.rng = random.Random(seed)
        self.w = w or ai.Weights()
        self.max_candidates = max_candidates

    def _candidates(self, actions):
        if self.max_candidates is None or len(actions) <= self.max_candidates:
            return actions
        keep = [a for a in actions if a[0] != "send"]
        sends = [a for a in actions if a[0] == "send"]
        return keep + self.rng.sample(sends, self.max_candidates - len(keep))

    def scores(self, view, actions):
        me = engine.to_play(view)
        out = []
        for a in actions:
            c = engine.clone(view, light=True)
            engine.apply(c, a)
            ai.finish_round(c, self.w)
            out.append((ai.value(c, me, self.w), a))
        return out

    def act(self, view, actions):
        if view.decision is not None and view.decision["type"] == "suit":
            return ai.suit_choice(view, actions)          # a suit only matters in later rounds' tricks
        return max(self.scores(view, self._candidates(actions)), key=lambda t: t[0])[1]


class PlannerBot:
    """Greedy's one-move search, without the blind spots the sim studies found.
    - It guesses what it can't see: rivals' hands, rivals' facedown cards and
      the deck, dealt at random from the cards it hasn't seen, `samples` times.
    - It plays the rest of the round out in each guess, with every player
      (itself included) on the rule-based policy, instead of ending the Present
      and the Past at once. So rivals do play into the tricks after it, and do
      act in the Past.
    - Its position value gives charge some worth past 12, an Ancestor in hand
      more than another card, and an ended game its margin, so it still plays
      for position in the last round.
    Every legal move gets Greedy's quick look in one guess; the best `shortlist`
    of them, plus drawing (or passing, when it can't draw), are played out in
    every guess. The same
    guesses and the same random numbers are used for every move, so moves are
    compared on equal terms."""

    name = "planner"

    def __init__(self, seed=None, w=None, samples=4, shortlist=6):
        self.rng = random.Random(seed)
        self.w = w or ai.Weights(charge_over=0.4, hand_ancestor=3.0)
        self.samples = samples
        self.shortlist = shortlist

    def _shortlist(self, world, actions, me):
        if ("draw",) in actions:                 # drawing is free and adds a card: never worse than passing,
            actions = [a for a in actions if a != ("pass",)]          # so don't spend play-outs on a pass
        keep = [a for a in actions if a[0] in ("draw", "pass") or a == ("wormhole", "stay", None, None)]
        rest = [a for a in actions if a not in keep]
        if len(rest) <= self.shortlist:
            return actions
        quick = []
        for a in rest:
            c = engine.clone(world, light=True)
            engine.apply(c, a)
            ai.finish_round(c, self.w)
            quick.append((ai.outcome(c, me, self.w), a))
        quick.sort(key=lambda t: -t[0])
        return keep + [a for _, a in quick[: self.shortlist]]

    def _play_out(self, world, a, me, seed):
        """Play move `a` in one guess, then the rest of the round on the rule-based policy."""
        c = engine.clone(world, light=True)
        c.rng = random.Random(seed)
        rules = [RuleBot(seed * 7 + q, w=self.w) for q in range(c.n)]

        def policy(st, acts):
            if st.decision is not None:
                return ai.quick_decision(st, acts, self.w)
            bot = rules[engine.to_play(st)]
            return bot._trick_card(st, acts) if acts[0][0] == "trick" else bot._past(st, acts)
        start = c.round
        engine.apply(c, a)
        engine.run_until(c, policy, lambda st: st.round != start)
        return ai.outcome(c, me, self.w)

    def act(self, view, actions):
        d = view.decision
        if d is not None and d["type"] == "suit":
            return ai.suit_choice(view, actions)          # a suit only matters in later rounds' tricks
        if d is not None and d["type"] == "activate":
            return ("activate", d["card"])
        me = engine.to_play(view)
        worlds = [ai.determinize(view, me, self.rng) for _ in range(self.samples)]
        seeds = [self.rng.randrange(1 << 30) for _ in worlds]
        cands = self._shortlist(worlds[0], actions, me)
        scored = [(sum(self._play_out(w, a, me, sd) for w, sd in zip(worlds, seeds)), i, a)
                  for i, a in enumerate(cands)]
        return max(scored, key=lambda t: (t[0], -t[1]))[2]


BOTS = {
    "random": lambda seed: RandomBot(seed),
    "rule": lambda seed: RuleBot(seed),
    "builder": lambda seed: RuleBot(seed, "builder"),
    "aggressor": lambda seed: RuleBot(seed, "aggressor"),
    "manipulator": lambda seed: RuleBot(seed, "manipulator"),
    "historian": lambda seed: RuleBot(seed, "historian"),
    "greedy": lambda seed: GreedyBot(seed),
    "planner": lambda seed: PlannerBot(seed),
}


def choose(bot, state):
    me = engine.to_play(state)
    actions = engine.legal_actions(state)
    if len(actions) == 1:
        return actions[0]
    return bot.act(engine.observe(state, me), actions)
