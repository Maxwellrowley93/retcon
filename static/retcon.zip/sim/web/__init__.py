"""Play Retcon in the browser against bots: `python -m sim.web`."""
