"""One human-vs-bots game, exposed as JSON for the web UI.

The human only ever sees `observe(state, human)`: opponents' facedown cards
and hands are hidden, and the log is scrubbed of what opponents sent back.
"""

import datetime
import json
import random
import re
from pathlib import Path

from .. import VERSION, engine
from ..bots import BOTS, choose
from ..cards import NAMES, SUIT_NAMES, SUITS, Kind, card_key, card_name, kind_of, suit_of
from ..config import Config
from ..engine import PLAYER_NAMES

COLORS = ["#d64545", "#3b6fd6", "#2f9e58", "#c99a1a"]
BOARD_DRAWING = re.compile(r"^T\d+[ *<]")          # the engine's text board, redundant in the UI
SECRET = re.compile(r"^(\s*)(\w+) (sends a card back into .*|plays a card into T\d+'s present"
                    r"|delivers a facedown card into T\d+) \[[^\]]+\]\.$")


class Session:
    def __init__(self, players=3, bot="greedy", seed=None, auto_ancestor=True):
        if not 2 <= players <= 4:
            raise ValueError("players must be 2-4")
        if bot not in BOTS:
            raise ValueError(f"unknown bot {bot}")
        self.seed = seed if seed is not None else random.randrange(1_000_000)
        self.bot_name = bot
        self.s = engine.new_game(Config(log=True), players, self.seed)
        self.human = 0
        self.bots = {p: BOTS[bot](self.seed * 7 + p) for p in range(players) if p != self.human}
        self.auto_ancestor = auto_ancestor
        self.mark = 0                      # log index where "since your last move" starts
        self.frames = []                   # one per log line since the human's last action (the replay)
        self._last_rows = None
        self.save_dir = None               # where a finished game's log is saved (the server sets it)
        self.saved = None                  # the file it went to
        self.s.observer = self._frame
        self.run_bots()

    # -- driving the game ------------------------------------------------------

    def run_bots(self):
        s = self.s
        while not engine.is_over(s):
            p = engine.to_play(s)
            acts = engine.legal_actions(s)
            if p == self.human:
                if len(acts) == 1:
                    engine.apply(s, acts[0])
                    continue
                d = s.decision
                if self.auto_ancestor and d and d["type"] == "activate" \
                        and engine._card_by_uid(s, d["card"]).kind == Kind.ANCESTOR:
                    engine.apply(s, ("activate", d["card"]))
                    continue
                return
            engine.apply(s, choose(self.bots[p], s))

    def act(self, index):
        s = self.s
        if engine.is_over(s) or engine.to_play(s) != self.human:
            raise ValueError("it is not your turn")
        acts = engine.legal_actions(s)
        if not 0 <= index < len(acts):
            raise ValueError("no such action")
        if s.decision is None:
            self.mark = len(s.log)
        self.frames, self._last_rows = [], None
        engine.apply(s, acts[index])
        self.run_bots()
        if engine.is_over(s) and self.save_dir is not None and self.saved is None:
            self.saved = self.save_log(self.save_dir)

    def save_log(self, directory):
        """Write the finished game's log for review: first as the human saw it, then
        in full, with every facedown card named. Returns the file's path."""
        directory = Path(directory)
        directory.mkdir(parents=True, exist_ok=True)
        stem = f"v{VERSION}-playtest-seed{self.seed}"
        path, n = directory / f"{stem}.txt", 1
        while path.exists():                       # the same seed played again
            n += 1
            path = directory / f"{stem}-{n}.txt"
        me, n_players = PLAYER_NAMES[self.human], self.s.n
        rivals = [PLAYER_NAMES[p] for p in range(n_players) if p != self.human]
        rivals = rivals[0] if len(rivals) == 1 else ", ".join(rivals[:-1]) + " and " + rivals[-1]
        bots = f"{self.bot_name} bot" + ("s" if n_players > 2 else "")
        full = [line for line in self.s.log if not BOARD_DRAWING.match(line)]
        text = "\n".join([
            f"# Retcon v{VERSION}, designer playtest: {me} (designer) vs {rivals} ({bots}), seed {self.seed}",
            f"# Saved {datetime.datetime.now():%Y-%m-%d %H:%M} by the web game.",
            f"# Part 1 is the log as {me} saw it: opponents' facedown plays are hidden until they flip.",
            "# Part 2 is the full log, with every facedown card named.",
            "", "## Part 1: as " + me + " saw it", "", *self._log(),
            "", "## Part 2: the full log", "", *full, ""])
        path.write_text(text, encoding="utf-8")
        return path

    def _frame(self, line):
        """Record one step of play for the step-by-step replay: the line as the
        human may see it, and the board as they see it right after that step."""
        if BOARD_DRAWING.match(line):
            return
        s = self.s
        rows = self._rows(engine.observe(s, self.human))
        key = json.dumps(rows, sort_keys=True)
        unchanged = key == self._last_rows
        self._last_rows = key
        self.frames.append({
            "line": self._scrub(line), "rows": None if unchanged else rows,
            "focus": s.focus, "hit": s.hit,
            "players": [{"points": pl.points, "charge": pl.charge} for pl in s.players],
            "instability": s.instability,
        })
        s.hit = None

    # -- JSON ------------------------------------------------------------------

    def _scrub(self, line):
        m = SECRET.match(line)
        if m and m.group(2) != PLAYER_NAMES[self.human]:
            return line[: line.rindex(" [")] + "."
        return line

    def _log(self):
        return [self._scrub(line) for line in self.s.log if not BOARD_DRAWING.match(line)]

    def _card(self, b, rid, i, c):
        return {
            "uid": c.uid, "kind": NAMES[c.kind] if c.kind != Kind.UNKNOWN else None,
            "owner": c.owner, "marks": {str(p): n for p, n in c.marks.items()},
            "pending": c.pending, "frozen": c.frozen, "anchored": c.anchored,
            "present": c.kind == Kind.PRESENT, "col": b.slot(rid, i), "row": rid, "index": i,
            "zone": c.zone, "suit": SUITS[c.suit] if c.suit is not None else None,
        }

    def _mark(self):
        """Index into the filtered log where lines since the human's last move begin."""
        return sum(1 for line in self.s.log[: self.mark] if not BOARD_DRAWING.match(line))

    def _label(self, view, a):
        t = a[0]
        if t == "draw":
            return "Draw a card"
        if t == "pass":
            return "Pass"
        if t == "send":
            via = f" (through T{a[4]})" if a[4] is not None else ""
            return f"Send back {card_name(a[1])} to T{a[2]}, gap {a[3]}{via}"
        if t == "split":
            x = view.board.card_at(a[1], a[2] - 1)
            if x.anchored:
                return f"Split at the start of T{a[1]}'s own history"
            return f"Split after {self._describe(view, x.uid)} (column {view.board.slot(a[1], a[2] - 1)})"
        if t == "trick":
            return f"Play {card_name(a[1])} into T{view.queue_rows[view.pos]}'s trick"
        if t == "usurp":
            return f"Remove {PLAYER_NAMES[a[1]]}'s lineage"
        if t == "courier":
            return f"Deliver {card_name(a[1])}" if a[1] is not None else "Don't deliver a card"
        if t == "suit":
            if a[1] is None:
                return "No suit (no trumps)"
            held = sum(1 for c in view.players[self.human].hand if suit_of(c) == a[1])
            return f"{SUITS[a[1]]} {SUIT_NAMES[a[1]]} (you hold {held})"
        if t == "activate":
            return "Activate"
        if t == "skip":
            return "Don't activate"
        if t == "wormhole":
            if a[1] == "stay":
                return "Leave it" if len(view.decision.get("sides", {})) < 2 else "Leave them"
            what = self._describe(view, a[3])
            side = view.decision.get("sides", {}).get(a[3])
            what += f" (just {side} the Wormhole)" if side else ""
            return {"down": f"Move {what} one slot earlier",
                    "up": f"Move {what} one slot later (in T{a[2]})",
                    "across": f"Move {what} across to T{a[2]}"}[a[1]]
        if t == "recall":
            return f"{card_name(a[1])}"
        if t == "lock":
            return f"Lock T{a[1]}"
        if t == "lock_done":
            return "Done locking"
        return " ".join(str(x) for x in a)

    def _describe(self, view, uid):
        """A card as the human may name it: facedown enemy cards stay anonymous."""
        rid, i = view.board.find(uid)
        c = view.board.card_at(rid, i)
        who = "your" if c.owner == self.human else (PLAYER_NAMES[c.owner] + "'s" if c.owner is not None else "the")
        kind = "facedown card" if c.kind == Kind.UNKNOWN else NAMES[c.kind]
        return f"{who} {kind} on T{rid}"

    def _prompt(self, view):
        d = view.decision
        if d is None:
            return None, None
        b = view.board
        if d["type"] == "activate":
            rid, i = b.find(d["card"])
            c = b.card_at(rid, i)
            return f"The sweep reaches your {NAMES[c.kind]} on T{rid} (column {b.slot(rid, i)}). Activate it?", d["card"]
        if d["type"] == "wormhole":
            names = " or ".join(self._describe(view, u) for u in d.get("sides", {}))
            if d.get("then"):
                return (f"Your Wormhole was struck by an {d['then'][1]} and acts first. It can move {names}: one slot "
                        "earlier, one slot later, or across to another timeline, swapping with the card in the same "
                        "slot since the split. Then the "
                        f"{d['then'][1]} hits whatever is next to it (moved into a later trick not yet scored, it "
                        "waits for that trick to be scored first)."), next(iter(d.get("sides", {})), None)
            return (f"Your Wormhole can move {names}: one slot earlier, one slot later, or across to another "
                    "timeline, swapping with the card in the same slot since the split."), next(iter(d.get("sides", {})), None)
        if d["type"] == "split":
            return (f"Your {d.get('cause', 'send')} took the instability to {engine.split_threshold(view)}: T{d['via']} ruptures, and "
                    "the instability goes back to 0. "
                    f"Choose where it splits: click a ⑂ in T{d['via']}'s history (or a button below). The new "
                    "timeline shares everything before that point, and the lineage on it. It starts empty, and gets "
                    "its first trick next round."), None
        if d["type"] == "usurp":
            return f"Your Usurper reaches {self._describe(view, d['card'])}. Whose lineage token goes home?", d["card"]
        if d["type"] == "courier":
            return (f"Your Courier arrives on T{d['row']}" + (" in this round's trick" if d["zone"] else "")
                    + ". Play a card from your hand facedown in its place? It acts straight away in this sweep.", None)
        if d["type"] == "suit":
            taken = [SUITS[r.cards[-1].suit] for r in b.rows if r.cards[-1].suit is not None]
            return (f"Your rupture created T{d['row']}. Choose its suit: in T{d['row']}'s trick, a card of that "
                    "suit is a trump and beats every card that isn't."
                    + (f" (Taken: {' '.join(taken)}.)" if taken else "")), None
        return d["type"], None

    def _rows(self, view):
        me = self.human
        b = view.board
        rows = []
        starts = b.slot_starts()
        for row in b.rows:
            tally = [engine.lineage(view, row.rid, p) for p in range(view.n)]
            record = view.lock_record.get(row.rid)
            if record is not None:
                tally = record["tally"]             # as it stood when it locked (its cards may be recycled)
            path = []
            for r, i in b.path(row.rid):           # the timeline's whole history, shared part included
                d = self._card(b, r, i, b.card_at(r, i))
                d["shared"] = r != row.rid
                path.append(d)
            now = next((j for j, d in enumerate(path) if d["zone"]), None)
            if now is not None:                    # draw the Present marker before the trick
                marker = path.pop()
                marker["index"] = path[now]["index"]   # its + sends a card to just behind the marker
                path.insert(now, marker)
            fork = None
            if row.parent is not None:
                prefix = b.shared_prefix(row.rid)
                if prefix:
                    x = b.card_at(*prefix[-1])
                    who = "" if x.owner is None else ("your " if x.owner == me else PLAYER_NAMES[x.owner] + "'s ")
                    fork = {"uid": x.uid, "label": who + (NAMES[x.kind] if x.kind != Kind.UNKNOWN else "facedown card")}
            suit = row.cards[-1].suit
            rows.append({
                "rid": row.rid, "parent": row.parent, "start": starts[row.rid], "locked": row.locked,
                "suit": SUITS[suit] if suit is not None else None,
                "path": path, "fork": fork, "tally": tally,
                "locked_by": record["player"] if record is not None else None,
            })
        return rows

    def to_json(self):
        s = self.s
        me = self.human
        view = engine.observe(s, me)
        rows = self._rows(view)
        my_turn = not engine.is_over(s) and engine.to_play(s) == me
        legal = []
        if my_turn:
            costs = engine.past_gaps(s, s.queue_rows[s.pos]) if s.phase == "past" and s.decision is None else {}
            gauge = engine.split_threshold(s) - s.instability       # what a send or recall must cost to rupture the timeline
            can_rupture = engine.can_rupture(s)
            for i, a in enumerate(engine.legal_actions(s)):   # the human's own options leak nothing
                item = {"i": i, "type": a[0], "label": self._label(view, a)}
                if a[0] == "send":
                    item.update(card=card_name(a[1]), kind=NAMES[kind_of(a[1])], row=a[2], gap=a[3], via=a[4])
                    if (a[2], a[3]) in costs:
                        item["cost"], jumped = costs[(a[2], a[3])]
                        item["steps"] = jumped + 1
                        item["label"] += f" ({item['cost']} charge)"
                        if can_rupture and item["cost"] >= gauge:
                            item["ruptures"] = True          # this send ruptures the timeline
                            item["label"] += f": T{a[4]} ruptures"
                elif a[0] == "recall":
                    if can_rupture and s.cfg.recall_cost >= gauge:
                        item["ruptures"] = True          # this recall ruptures the timeline
                        item["label"] += f": T{s.queue_rows[s.pos]} ruptures"
                elif a[0] == "split":
                    item.update(row=a[1], gap=a[2], via=s.decision["via"])
                elif a[0] == "trick":
                    item.update(card=card_name(a[1]), kind=NAMES[kind_of(a[1])])
                legal.append(item)
        prompt, focus = self._prompt(view) if my_turn else (None, None)
        discard = {}
        for k in view.discard:
            name = NAMES[kind_of(k)]
            discard[name] = discard.get(name, 0) + 1
        return {
            "seed": self.seed, "bot": self.bot_name, "human": me,
            "saved": str(self.saved) if self.saved else None,
            "round": view.round, "actions_per_round": view.actions_this_round,
            "first": view.first, "phase": view.phase, "over": engine.is_over(s),
            "winners": list(s.winners), "end_reason": s.end_reason,
            "to_play": engine.to_play(s), "my_turn": my_turn,
            "decision": view.decision["type"] if view.decision else None,
            "prompt": prompt, "focus": focus,
            "trick_row": view.queue_rows[view.pos]          # the timeline this Present or Past action is for
            if view.phase in ("present", "past") and view.pos < len(view.queue_rows) else None,
            "version": VERSION, "round_limit": s.cfg.round_limit,
            "max_timelines": s.cfg.timeline_cap, "total_timelines": engine.total_cap(s),
            "can_rupture": engine.can_rupture(s), "locks_to_win": s.cfg.locks_to_win,
            "instability": s.instability, "split_at": engine.split_threshold(s),
            "players": [{
                "name": PLAYER_NAMES[p], "color": COLORS[p], "points": pl.points,
                "hand_count": len(pl.hand), "markers": pl.markers, "peak_markers": pl.peak_markers, "lineage_left": pl.supply,
                "charge": pl.charge, "tricks": pl.tricks,
            } for p, pl in enumerate(view.players)],
            "hand": [{"card": card_name(c), "kind": NAMES[kind_of(c)],
                      "suit": SUITS[suit_of(c)] if suit_of(c) is not None else None}
                     for c in sorted(view.players[me].hand, key=card_key)],
            "deck": len(view.deck), "discard": discard,
            "rows": rows, "legal": legal,
            "log": self._log(), "mark": self._mark(), "frames": self.frames,
            "rules": {"secure": s.cfg.tokens_to_secure, "recall_cost": s.cfg.recall_cost,
                      "values": {NAMES[k]: v for k, v in s.cfg.trick_values.items()}},
        }
