"""The web game's three calls, shared by the local server (server.py) and the browser build
(standalone/build_web.py, where this runs under Pyodide): one game at a time, in `holder`."""

from .session import Session


def handle(holder, path, body, save_dir=None):
    """Answer GET /api/state (body None), POST /api/new or POST /api/act. Returns (status, json)."""
    if path == "/api/state" and body is None:
        if holder.get("game") is None:
            return 200, {"none": True}
        return 200, holder["game"].to_json()
    try:
        if path == "/api/new":
            holder["game"] = Session(**body)
            holder["game"].save_dir = save_dir
        elif path == "/api/act":
            if holder.get("game") is None:
                return 400, {"error": "no game"}
            holder["game"].act(int(body["i"]))
        else:
            return 404, {"error": "not found"}
    except (ValueError, TypeError, KeyError) as e:
        return 400, {"error": str(e)}
    return 200, holder["game"].to_json()
