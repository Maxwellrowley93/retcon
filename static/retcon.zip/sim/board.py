"""The multiverse: a tree of rows, each row being one timeline.

A row's timeline *path* is the shared prefix of every ancestor row followed by
all of its own cards. Columns are derived from the tree, never stored:
start(root) = 0, start(child) = start(parent) + k.
"""

from .cards import Kind, NAMES, SUITS

PLAYER_INITIALS = "RBGY"


class BoardCard:
    __slots__ = ("uid", "kind", "owner", "marks", "pending", "frozen", "anchored", "zone", "suit")

    def __init__(self, uid, kind, owner, pending=False):
        self.uid = uid
        self.kind = kind
        self.owner = owner          # player index (signal marker), or None for neutral cards
        self.marks = {}             # player -> lineage tokens that player has on this card (D16)
        self.pending = pending      # facedown, not yet revealed
        self.frozen = False         # on a locked timeline's path
        self.anchored = False       # a split point: the neutral start of a branch row
        self.zone = 0               # 0 = history, 1 = this round's trick beyond the Present marker
        self.suit = None            # index into SUITS (a Present's is its timeline's)

    @property
    def tokens(self):
        """Total lineage tokens on the card. Assigning puts them all in the owner's
        colour (a shortcut for setting up positions)."""
        return sum(self.marks.values())

    @tokens.setter
    def tokens(self, n):
        self.marks = {self.owner: n} if n else {}

    def mark(self, player, n=1):
        self.marks[player] = self.marks.get(player, 0) + n
        if self.marks[player] <= 0:
            del self.marks[player]

    def clone(self):
        c = BoardCard.__new__(BoardCard)
        c.uid, c.kind, c.owner, c.marks = self.uid, self.kind, self.owner, dict(self.marks)
        c.pending, c.frozen, c.anchored, c.zone = self.pending, self.frozen, self.anchored, self.zone
        c.suit = self.suit
        return c

    def __repr__(self):
        return f"<{label(self)}>"


class Row:
    __slots__ = ("rid", "parent", "k", "cards", "locked")

    def __init__(self, rid, parent, k, cards):
        self.rid = rid
        self.parent = parent        # parent row id, or None for a root row
        self.k = k                  # number of the parent's own cards shared
        self.cards = cards          # list[BoardCard]; the last is always a Present card
        self.locked = False


class Board:
    def __init__(self):
        self.rows = []

    def clone(self):
        b = Board()
        for r in self.rows:
            row = Row(r.rid, r.parent, r.k, [c.clone() for c in r.cards])
            row.locked = r.locked
            b.rows.append(row)
        return b

    # ----- structure -------------------------------------------------------

    def add_row(self, parent, k, cards):
        row = Row(len(self.rows), parent, k, cards)
        self.rows.append(row)
        return row.rid

    def children(self, rid):
        return [r.rid for r in self.rows if r.parent == rid]

    def subtree(self, rid):
        out = [rid]
        for c in self.children(rid):
            out.extend(self.subtree(c))
        return out

    def start(self, rid):
        row = self.rows[rid]
        return 0 if row.parent is None else self.start(row.parent) + row.k

    def col(self, rid, i):
        return self.start(rid) + i

    def slot(self, rid, i):
        """Card i of row rid's timeslot, as drawn: timelines line up slot for
        slot, so a slot is the number of cards
        before it along its path, with split points not counting, so the first
        card after a split lines up with the first card after it on the other
        timeline. An anchor sits beside the last card its two timelines share, in
        that card's slot (-1 for a timeline with no shared past)."""
        before = self.path(rid)[: len(self.shared_prefix(rid)) + i]
        n = sum(1 for r, j in before if not self.rows[r].cards[j].anchored)
        return n - 1 if self.rows[rid].cards[i].anchored else n

    def slot_starts(self):
        """Where each row's own cards start when drawn slot for slot, shifted so
        that none is left of the edge."""
        starts = {row.rid: self.slot(row.rid, 0) for row in self.rows}
        low = min(starts.values(), default=0)
        return {rid: s - min(low, 0) for rid, s in starts.items()}

    def shared_prefix(self, rid):
        row = self.rows[rid]
        if row.parent is None:
            return []
        return self.shared_prefix(row.parent) + [(row.parent, i) for i in range(row.k)]

    def path(self, rid):
        return self.shared_prefix(rid) + [(rid, i) for i in range(len(self.rows[rid].cards))]

    def timelines_through(self, rid, i):
        """Timelines whose path contains position i of row rid (or gains a card
        when something is inserted at gap i)."""
        out = [rid]
        for c in self.children(rid):
            if self.rows[c].k > i:
                out.extend(self.subtree(c))
        return out

    def card_at(self, rid, i):
        return self.rows[rid].cards[i]

    def find(self, uid):
        for row in self.rows:
            for i, c in enumerate(row.cards):
                if c.uid == uid:
                    return row.rid, i
        raise KeyError(uid)

    def all_cards(self):
        for row in self.rows:
            for i, c in enumerate(row.cards):
                yield row.rid, i, c

    def active_rows(self):
        return [r.rid for r in self.rows if not r.locked]

    # ----- gaps ------------------------------------------------------------

    def gap_usable(self, rid, g):
        row = self.rows[rid]
        if g < 0 or g > len(row.cards) - 1:    # never after the Present card
            return False
        if row.parent is not None and g == 0 and row.cards[0].anchored:
            return False                       # the split point stays attached
        return True

    def gap_frozen(self, rid, g):
        return any(self.rows[t].locked for t in self.timelines_through(rid, g))

    def path_gaps(self, rid):
        """Gaps whose insertion adds a card to timeline rid's path, its shared history included."""
        gaps = [(rid, g) for g in range(len(self.rows[rid].cards)) if self.gap_usable(rid, g)]
        r = rid
        while self.rows[r].parent is not None:
            k, p = self.rows[r].k, self.rows[r].parent
            gaps.extend((p, g) for g in range(k) if self.gap_usable(p, g))
            r = p
        return [gp for gp in gaps if not self.gap_frozen(*gp)]

    # ----- mutation --------------------------------------------------------

    def insert(self, rid, g, card):
        self.rows[rid].cards.insert(g, card)
        for c in self.children(rid):
            if g < self.rows[c].k:
                self.rows[c].k += 1

    def remove(self, rid, i):
        card = self.rows[rid].cards.pop(i)
        for c in self.children(rid):
            if self.rows[c].k > i:
                self.rows[c].k -= 1
        return card

    def swap(self, a, b):
        (ra, ia), (rb, ib) = a, b
        ca, cb = self.rows[ra].cards[ia], self.rows[rb].cards[ib]
        self.rows[ra].cards[ia], self.rows[rb].cards[ib] = cb, ca

    # ----- searches --------------------------------------------------------

    def _zone(self, rid, i, cross):
        cards = self.rows[rid].cards
        return None if cross or not 0 <= i < len(cards) else cards[i].zone

    def search_right(self, rid, i, match=None, first_only=False, skip=None, cross=False):
        """Walk forward from (rid, i). The walk splits at every fork it passes;
        each branch stops at its own first match. With first_only, each branch
        returns its first card not passed over by `skip`, whatever it is.
        A walk never crosses the Present marker (a change of zone) unless `cross`."""
        results = []
        zone = self._zone(rid, i, cross)

        def walk(r, j):
            row = self.rows[r]
            kids = self.children(r)
            while j < len(row.cards):
                for c in kids:
                    if self.rows[c].k == j:
                        walk(c, 0)
                card = row.cards[j]
                if zone is not None and card.zone != zone:
                    return
                if first_only and not (skip and skip(card)) or not first_only and match(card):
                    results.append((r, j))
                    return
                j += 1

        walk(rid, i + 1)
        return results

    def search_left(self, rid, i, match=None, cross=False):
        """Walk back along the path from (rid, i); return the first match.
        Like search_right, it stops at the Present marker unless `cross`."""
        zone = self._zone(rid, i, cross)
        r, j = rid, i - 1
        while True:
            row = self.rows[r]
            while j >= 0:
                if zone is not None and row.cards[j].zone != zone:
                    return None
                if match is None or match(row.cards[j]):
                    return r, j
                j -= 1
            if row.parent is None:
                return None
            r, j = row.parent, row.k - 1

    # ----- queries ---------------------------------------------------------

    def tokens_on(self, rid, player):
        total = 0
        for r, i in self.path(rid):
            total += self.rows[r].cards[i].marks.get(player, 0)
        return total

    # ----- rendering -------------------------------------------------------

    def render(self, width=15):
        """One line per timeline, lined up slot for slot (see slot): a split point
        sits under the last card its timelines share."""
        lines = []
        starts = self.slot_starts()
        for row in self.rows:
            head = f"T{row.rid}" + ("*" if row.locked else " ")
            if row.parent is not None:
                head += f"<T{row.parent}"
            head = head.ljust(8)
            # this round's trick is drawn beyond the Present marker
            ordered = [c for c in row.cards if not c.zone] + [c for c in row.cards if c.zone]
            cells = "".join(label(c).ljust(width) for c in ordered)
            lines.append(head + " " * (width * starts[row.rid]) + cells)
        return "\n".join(lines)


def label(c, hide_pending=False):
    suit = SUITS[c.suit] if c.suit is not None and not (c.pending and hide_pending) else ""
    if c.kind == Kind.PRESENT:
        return f"[PRESENT{suit}]"
    who = PLAYER_INITIALS[c.owner] if c.owner is not None else "-"
    if c.pending:
        body = "?" if hide_pending else "?" + NAMES[c.kind]
    else:
        body = NAMES[c.kind]
    tok = "".join(f" {PLAYER_INITIALS[p]}{n}" for p, n in sorted(c.marks.items()))
    ice = "*" if c.frozen else ""
    return f"[{who}:{suit}{body}{tok}{ice}]"
